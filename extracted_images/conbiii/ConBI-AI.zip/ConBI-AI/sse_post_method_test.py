# --- Updated app.py ---

import asyncio
import json
import random
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
# Import necessary Pydantic components and typing
from pydantic import BaseModel, Field
from typing import Dict, Any, AsyncGenerator, List, Optional

# --- USER PROVIDED Pydantic Models ---
class Auth(BaseModel):
    api_key: str = Field(...) # Assuming api_key is always required

class RequestOptions(BaseModel):
    set_any_params: bool

class LLMModelConfig(BaseModel):
    name: str
    platform: str
    api_key: str # Sensitive

class RequestData(BaseModel):
    chat_history: List[Dict[str, Any]] # List of generic dicts for history entries
    curr_user_query: str
    database_detail: Dict[str, Any] # Database details as a dictionary
    AIModel: LLMModelConfig
    summary_task_model: Optional[LLMModelConfig] = None
    sql_gen_task_model: Optional[LLMModelConfig] = None
    query_refiner_task_model: Optional[LLMModelConfig] = None
    error_correction_task_model: Optional[LLMModelConfig] = None
    unspecialized_task_model: Optional[LLMModelConfig] = None
    error_summary_task_model: Optional[LLMModelConfig] = None

class RequestEnvelope(BaseModel):
    # Use the field name 'auth' for FastAPI request parsing.
    # The alias mainly affects serialization (model -> dict/JSON).
    auth: Auth
    options: RequestOptions
    data: RequestData
# --- End User Provided Models ---

app = FastAPI()

# --- Basic CORS for local development ---
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

def format_sse(data: Dict[str, Any]) -> bytes:
    """Formats dict into SSE message bytes."""
    return f"data: {json.dumps(data)}\n\n".encode("utf-8")

# Generator now accepts the user-defined RequestEnvelope
async def complex_payload_stream_generator(payload: RequestEnvelope) -> AsyncGenerator[bytes, None]:
    """Yields messages based on the received RequestEnvelope payload."""

    # Access data using the user-defined model structure
    user_query = payload.data.curr_user_query
    # Access db_type from the dictionary within RequestData
    db_type = payload.data.database_detail.get('database_type', 'Unknown')
    model_name = payload.data.AIModel.name
    auth_key_used = bool(payload.auth.api_key) # Check if key exists without logging it

    # Print some info on the server side for verification
    print(f"Received Query: {user_query}")
    print(f"DB Type: {db_type}")
    print(f"Model Name: {model_name}")
    print(f"Auth Key Provided: {auth_key_used}")

    # Send initial message
    yield format_sse({"sse_status": "open", "chunk_data": {"info": f"Processing Started for query: {user_query}"}})
    await asyncio.sleep(0.5)

    # Simulate sending step data
    for i in range(1, 4): # Send 3 steps
        yield format_sse({"sse_status": "chunk", "chunk_data": {"step": i, "status": f"Running step {i} using {db_type} DB..."}})
        await asyncio.sleep(random.uniform(0.3, 1.0))

    # Send close signal
    yield format_sse({"sse_status": "close", "chunk_data": {"final_message": "Finished Processing"}})
    print("Stream Finished.")

# --- POST Endpoint (Path matches client, accepts user's RequestEnvelope) ---
@app.post("/api/ask-query-chunk-response-test")
async def complex_post_sse_endpoint(payload: RequestEnvelope): # Use RequestEnvelope
    return StreamingResponse(complex_payload_stream_generator(payload), media_type="text/event-stream")

@app.get("/")
def root(): return {"message": "SSE POST Backend with User Models"}

# --- To Run ---
# 1. Save as app.py
# 2. Ensure FastAPI, Uvicorn, Pydantic are installed: pip install fastapi uvicorn pydantic
# 3. Run: uvicorn app:app --reload

























# from fastapi import FastAPI
# from starlette.middleware.cors import CORSMiddleware
# from starlette.responses import StreamingResponse
# import asyncio
# import random
# import json
# # Import necessary types from the typing module
# from typing import Dict, Any, AsyncGenerator
# from pydantic import BaseModel, Field

# app = FastAPI()

# # Allow CORS for all origins (or specify specific origins if needed)
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],  # Allow all origins, replace "*" with specific domains for security
#     allow_credentials=True,
#     allow_methods=["*"],  # Allow all HTTP methods (GET, POST, etc.)
#     allow_headers=["*"],  # Allow all headers
# )

# # ✅ Full request envelope model with top-level fields:
# #    timestamp, fastapi-auth, options, and data.
# class RequestEnvelope(BaseModel):
#     None




# # Combined function replacing chunk_response and final_chunk_response
# def format_sse_message(status, chunk_data) -> str:

#     # Create the dictionary structure
#     sse_status_and_chunk_data = {
#         "sse_status": status,
#         "chunk_data": chunk_data
#     }

#     # Return the data as a JSON string
#     return json.dumps(sse_status_and_chunk_data)



# # Combined function replacing chunk_response and final_chunk_response
# def format_sse_message(status, chunk_data) -> str:

#     # Create the dictionary structure
#     sse_status_and_chunk_data = {
#         "sse_status": status,
#         "chunk_data": chunk_data
#     }

#     # Return the data as a JSON string
#     return json.dumps(sse_status_and_chunk_data)





# async def event_stream(payload: RequestEnvelope) -> AsyncGenerator[str, None]:

#     # Yield 1st message
#     yield f"data: {format_sse_message("open", {"message": "chunked_response 1"} )}\n\n"
#     # await asyncio.sleep(0.5) # Add a small delay (e.g., 0.5 seconds)

#     # Yield 2nd message
#     yield f"data: {format_sse_message("open", {"message": "chunked_response 2"} )}\n\n"
    
#     # await asyncio.sleep(0.5) # Add another small delay

#     # Yield 2nd message
#     yield f"data: {format_sse_message("open", {"message": "chunked_response 3"} )}\n\n"
#     # await asyncio.sleep(0.5) # Add another small delay

#     yield f"data: {format_sse_message("close", {"message": "finished early"} )}\n\n"

#     # Yield 2nd message
#     yield f"data: {format_sse_message("open", {"message": "chunked_response 4"} )}\n\n"
#     # await asyncio.sleep(0.5) # Add another small delay

#     # Yield final message
#     yield f"data: {format_sse_message("close", {"message": "final_chunked_response"} )}\n\n"

#     # return f"data: {format_sse_message("close", {"message": "message finished"})}\n\n"


# # Endpoint to stream data with SSE
# @app.post("/api/ask-query-chunk-response-test")
# async def ask_query_chunk_response(payload: RequestEnvelope): # Renamed function to avoid conflict with module name if saved as sse.py
#     # StreamingResponse handles the Content-Type and other necessary headers
#     # when media_type is 'text/event-stream'.
#     # Just pass the async generator directly.
#     async def event_source():
#         # Send HTTP headers for the SSE response
#         yield b"HTTP/1.1 200 OK\r\n"
#         yield b"Content-Type: text/event-stream\r\n"
#         yield b"Cache-Control: no-cache\r\n"
#         yield b"Connection: keep-alive\r\n"
#         yield b"\r\n"  # End of headers

#         yield f"data: {format_sse_message("open", {"message": "test messsage"} )}\n\n"
#         # Stream the data
#         async for data in event_stream(payload):
#             if "sse_status: close" in data:
#                 break
#             yield data.encode()  # Ensure that the data is encoded as bytes


#     return StreamingResponse(event_source(), media_type="text/event-stream")
