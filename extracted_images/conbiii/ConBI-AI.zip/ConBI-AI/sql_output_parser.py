# ----------------------------------------
# 📁 sql_output_parser.py (Shared SQL output handling)
# ----------------------------------------
import re
import json
from pydantic import BaseModel, ValidationError
import re

# ----------------------------------------
# Pydantic Models for Output Structure
# ----------------------------------------
class SQLGenerationOutput(BaseModel):
    """Pydantic model expecting only the 'final_sql' key."""
    final_sql: str

# (Input model kept assuming it's used elsewhere)
class SQLGenerationInput(BaseModel):
    natural_language_query: str
    schema_str: str

# ----------------------------------------
# Helper Functions
# ----------------------------------------
def clean_llm_output(raw_output: str) -> str:
    """Strips leading/trailing whitespace."""
    return raw_output.strip()


def is_sql_safe(sql_query: str) -> bool:
    """
    Checks if the SQL query is likely safe (SELECT-only, allows CTEs/comments, no dangerous keywords).
    """
    # 1. Strip leading/trailing whitespace initially
    sql_strip = sql_query.strip()

    # 2. Remove leading comments iteratively
    # Remove /* ... */ style comments at the beginning
    # Using re.IGNORECASE for potentially different casing in comments, though unlikely
    sql_strip = re.sub(r"^\s*/\*.*?\*/\s*", "", sql_strip, flags=re.DOTALL | re.IGNORECASE)
    # Remove -- style comments at the beginning (potentially multiple lines)
    # Loop to handle multiple consecutive comment lines
    original_length = -1
    while len(sql_strip) != original_length: # Keep removing until no change
        original_length = len(sql_strip)
        sql_strip = re.sub(r"^\s*--[^\r\n]*($|\r?\n)", "", sql_strip, flags=re.IGNORECASE).strip()

    # If empty after stripping comments/whitespace, it's not a valid/safe query
    if not sql_strip:
        return False

    # 3. Check starting keyword (SELECT or WITH) on the cleaned string
    sql_upper = sql_strip.upper()
    if not (sql_upper.startswith("SELECT") or sql_upper.startswith("WITH")):
        # Optional: Add check for starting parenthesis here if deemed necessary
        # if sql_upper.startswith("("): ... handle recursively or allow ...
        return False

    # 4. Basic check: If it starts with WITH, SELECT should appear later
    if sql_upper.startswith("WITH") and "SELECT" not in sql_upper:
        return False # Might be incomplete CTE or non-SELECT use of WITH

    # 5. Check for disallowed keywords anywhere in the original query (case-insensitive)
    # Use original query text to avoid issues with keywords inside comments we removed
    disallowed_patterns = [
        r"\b(DELETE|INSERT|UPDATE|DROP|ALTER|TRUNCATE|CREATE|EXEC(UTE)?|GRANT|REVOKE|SHUTDOWN)\b"
    ]
    if re.search(disallowed_patterns[0], sql_query, re.IGNORECASE):
        return False

    # 6. If all checks pass
    return True



# ----------------------------------------
# Main Extraction Function (Simplified)
# ----------------------------------------
def extract_generated_sql(raw_output: str) -> SQLGenerationOutput:
    """
    Extracts the final_sql from the LLM's simplified JSON output. Stripped down version.

    Args:
        raw_output: The raw string response from the LLM.

    Returns:
        An SQLGenerationOutput object containing the final_sql.

    Raises:
        ValueError: If the output cannot be parsed or validated against the expected format.
    """
    cleaned_output = clean_llm_output(raw_output)
    try:
        # Attempt to parse and validate in one go
        sql_output = SQLGenerationOutput(**json.loads(cleaned_output))
        # Optional: uncomment below to enforce safety check before returning
        if not is_sql_safe(sql_output.final_sql):
           raise ValueError("Generated SQL failed safety check.")
        return sql_output
    except (json.JSONDecodeError, ValidationError) as e:
        # Catch JSON parsing and Pydantic validation errors together
        raise ValueError(f"LLM output failed parsing or validation: {e}") from e
    except Exception as e:
        # Catch any other unexpected errors during processing
        raise ValueError(f"Unexpected error during SQL extraction: {e}") from e
