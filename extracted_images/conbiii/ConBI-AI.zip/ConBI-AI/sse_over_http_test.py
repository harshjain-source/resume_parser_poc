from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware
from starlette.responses import StreamingResponse
import asyncio
import random
import json
# Import necessary types from the typing module
from typing import Dict, Any, AsyncGenerator

app = FastAPI()

# Allow CORS for all origins (or specify specific origins if needed)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins, replace "*" with specific domains for security
    allow_credentials=True,
    allow_methods=["*"],  # Allow all HTTP methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
)

# No changes needed in these helper functions definition-wise,
# but the type hints Dict and Any will now be recognized.

# Combined function replacing chunk_response and final_chunk_response
def format_sse_message(status, chunk_data) -> str:

    # Create the dictionary structure
    sse_status_and_chunk_data = {
        "sse_status": status,
        "chunk_data": chunk_data
    }

    # Return the data as a JSON string
    return json.dumps(sse_status_and_chunk_data)


async def event_stream() -> AsyncGenerator[str, None]:
    steps = 5  # Total steps for sending data chunks
    for i in range(steps):
        # Simulating delay between steps (1 to 3 seconds)
        await asyncio.sleep(random.uniform(1, 2)) # Use uniform for potentially smoother demo

        status = "open"  # <--- FIX: Correct variable name
        chunk_data = {
                    "metadata_file": "db_schema_embeddings/mssql/rodic_bi/db_schema.txt",
                    "index_file": "db_schema_embeddings/mssql/rodic_bi/db_schema_embedding.index",
                    "total_tables": 3,
                    "total_columns": 29
                }
        # <--- FIX: Removed stray backslash from here

        # Yield the chunk data formatted for SSE: "data: <json_string>\n\n"
        yield f"data: {format_sse_message(status, chunk_data)}\n\n" # <--- FIX: Use correct variable name


    # Yield the final chunk formatted for SSE
    # (Corrected typo in message content)
    yield f"data: {format_sse_message("close", {"message": "message finished"})}\n\n"
    # The connection will be closed by StreamingResponse when the generator finishes

# Endpoint to stream data with SSE
@app.get("/api/ask-query-chunk-response")
async def ask_query_chunk_response(): # Renamed function to avoid conflict with module name if saved as sse.py
    # StreamingResponse handles the Content-Type and other necessary headers
    # when media_type is 'text/event-stream'.
    # Just pass the async generator directly.
    async def event_source():
        # Send HTTP headers for the SSE response
        yield b"HTTP/1.1 200 OK\r\n"
        yield b"Content-Type: text/event-stream\r\n"
        yield b"Cache-Control: no-cache\r\n"
        yield b"Connection: keep-alive\r\n"
        yield b"\r\n"  # End of headers

        # Stream the data
        async for data in event_stream():
            yield data.encode()  # Ensure that the data is encoded as bytes


    return StreamingResponse(event_source(), media_type="text/event-stream")


# Main FastAPI app execution block
if __name__ == "__main__":
    import uvicorn
    # Ensure the app object passed matches the filename and app variable name
    # If your file is named 'sse_over_http_test.py', use 'sse_over_http_test:app'
    uvicorn.run("sse_over_http_test:app", host="0.0.0.0", port=8000, reload=True) # Added reload=True for convenience






#============================================================================


'''
from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware
from starlette.responses import StreamingResponse
import asyncio
import random

app = FastAPI()

# Allow CORS for all origins (or specify specific origins if needed)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins, replace "*" with specific domains for security
    allow_credentials=True,
    allow_methods=["*"],  # Allow all HTTP methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
)

# Function to simulate data being sent to the client at random intervals
async def event_stream():
    steps = 5  # Sending 5 parts of data
    for i in range(steps):
        await asyncio.sleep(random.randint(1, 3))  # Random time between 1 to 3 seconds
        yield f"data: Step {i + 1} at {asyncio.get_event_loop().time()} seconds\n\n"
    
    # After 5 steps, the connection will be closed gracefully
    yield "data: Connection closed\n\n"
    # yield "retry: 0\n"  # Tells the client not to reconnect

@app.get("/sse")
async def sse():
    async def event_source():
        # Send HTTP headers for the SSE response
        yield b"HTTP/1.1 200 OK\r\n"
        yield b"Content-Type: text/event-stream\r\n"
        yield b"Cache-Control: no-cache\r\n"
        yield b"Connection: keep-alive\r\n"
        yield b"\r\n"  # End of headers

        # Stream the data
        async for data in event_stream():
            yield data.encode()  # Ensure that the data is encoded as bytes

    return StreamingResponse(event_source(), media_type="text/event-stream")

'''












#============================================================================

# Using close connection fucnction way 

'''
import asyncio
import random

# Function to simulate sending a part of the data
async def send_step(i):
    await asyncio.sleep(random.randint(1, 3))  # Random time between 1 to 3 seconds
    return f"data: Step {i + 1} at {asyncio.get_event_loop().time()} seconds\n\n"

# Function to simulate closing the connection
async def close_connection():
    return "data: Connection closed\n\n"

# Event stream function to send multiple data chunks
async def event_stream():
    steps = 5
    for i in range(steps):
        # If step 3, close the connection after sending the message
        if i == 3:
            yield await close_connection()
            break
        yield await send_step(i)

# Simulate running the event stream
async def main():
    async for message in event_stream():
        print(message)

# Run the event stream
asyncio.run(main())

'''