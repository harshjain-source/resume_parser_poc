import os
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

# Initialize embeddings_in_ram
embeddings_in_ram = {
    "models": [],  # List for storing models
    "db": {}       # Dictionary: db_type → label_name → list of embeddings
}

# Load DB embeddings into RAM using label_name as folder
def load_db_embeddings_in_ram(db_type, label_name):
    db_type = db_type.lower()
    label_name = label_name.lower().replace(" ", "_").replace("-", "_")  # Clean label

    # Initialize db_type if not present
    if db_type not in embeddings_in_ram["db"]:
        embeddings_in_ram["db"][db_type] = {}

    # Initialize label_name entry
    if label_name not in embeddings_in_ram["db"][db_type]:
        embeddings_in_ram["db"][db_type][label_name] = []

    # Build file paths
    db_folder = os.path.join("db_schema_embeddings", db_type, label_name)

    # FAISS index and schema files for business rules
    index_filename = os.path.join(db_folder, "db_schema_embedding.index")
    db_schema_filename = os.path.join(db_folder, "db_schema.txt")

    # New files for business embeddings
    business_index_filename = os.path.join(db_folder, "business_embedding.index")
    business_schema_filename = os.path.join(db_folder, "business_schema.txt")

    # Check for missing files for both schema and business
    if not os.path.exists(index_filename) or not os.path.exists(db_schema_filename):
        print(f"❌ Missing required files for {label_name} in {db_type}")
        return

    # Load FAISS index and schema
    index = faiss.read_index(index_filename)

    # Read schema lines
    with open(db_schema_filename, "r", encoding="utf-8") as f:
        db_schema_lines = f.readlines()

    # Initialize variables for business files
    business_index = None
    business_schema_lines = []

    # Read business schema and embedding files if they exist
    if os.path.exists(business_index_filename) and os.path.exists(business_schema_filename):
        business_index = faiss.read_index(business_index_filename)
        with open(business_schema_filename, "r", encoding="utf-8") as f:
            business_schema_lines = f.readlines()
        print(f"✅ Loaded business files for {label_name} under {db_type} into RAM.")
    else:
        print(f"⚠️ Business files missing for {label_name} under {db_type}, skipping business data loading.")

    # Save to RAM
    embeddings_in_ram["db"][db_type][label_name].append({
        "index_file": index,
        "db_schema_lines": db_schema_lines,
        "business_index_file": business_index,
        "business_schema_lines": business_schema_lines
    })

    

    print(f"✅ Loaded {label_name} under {db_type} into RAM.")

# Scan all db_type/label_name folders
def scan_and_load_db_schema_embeddings_in_ram(base_folder="db_schema_embeddings"):
    for db_type in os.listdir(base_folder):
        db_type_folder = os.path.join(base_folder, db_type)

        if os.path.isdir(db_type_folder):
            print(f"🔍 Found DB Type: {db_type}")
            for label_name in os.listdir(db_type_folder):
                label_folder = os.path.join(db_type_folder, label_name)

                if os.path.isdir(label_folder):
                    print(f"  📁 Found Label: {label_name}")
                    load_db_embeddings_in_ram(db_type, label_name)


# Main logic
if __name__ == "__main__":
    # Load the embedding model (same one used for generating embeddings)
    embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

    # Store the embedding model in embeddings_in_ram["models"]
    embeddings_in_ram["models"].append(embedding_model)

    # Scan and load the DB schema embeddings from the folder structure
    scan_and_load_db_schema_embeddings_in_ram()

    # Print the loaded embeddings_in_ram for verification
    print("\nLoaded embeddings_in_ram:")
    print(embeddings_in_ram)

    # Example of how to access the data
    print("Stored FAISS index and schema for mssql -> rodic_bi:")
    print(embeddings_in_ram["db"]["mssql"]["rodic_bi"][0]["index_file"])  # FAISS index object
    print(embeddings_in_ram["db"]["mssql"]["rodic_bi"][0]["db_schema_lines"])  # Schema lines
