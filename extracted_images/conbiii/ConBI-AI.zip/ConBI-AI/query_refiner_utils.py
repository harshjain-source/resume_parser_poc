# ----------------------------------------
# 📁 query_refiner_utils.py (Query refiner prompt builder and parser)
# ----------------------------------------
import re
import json
from context import curr_user_query_ctx, chat_history_ctx, retrieved_db_schema_for_query_ctx,database_detail_ctx,index_list_ctx


# ✅ Prompt Builder (Readable, structured, system-user split)

# def build_refiner_prompt() -> list:
#     # Pass chat_history as-is for highest fidelity
#     history_formatted = json.dumps(chat_history_ctx.get(), indent=2)

#     print("history_formatted: ", history_formatted)

#     system_prompt = (
#         "You are an advanced query refinement assistant. Your task is to process a raw user query and return clear, corrected, and context-aware refined queries suitable for SQL generation."
#         "\n\nFollow these internal steps before answering:"
#         "\n1. Analyze the query"
#         "\n2. Identify goals and correct errors"
#         "\n3. Apply follow-up context from chat history (if any)"
#         "\n4. Decide if query should be split or combined based on SQL feasibility"
#         "\n5. Output refined natural language query/queries only (no SQL)."

#         "\n\nChat History (newest first):"
#         f"\n{history_formatted}"

#         "\n\nDatabase Schema:"
#         f"\n{retrieved_db_schema_for_query_ctx.get()}"

#         "\n\nIMPORTANT: Return ONLY the following exact format (no extra text):\n"
#         "count: [number_of_queries]\n"
#         "queries:\n"
#         "  - query 1\n"
#         "  - query 2\n"
#         "  - ..."
#     )

#     return [
#         {"role": "system", "content": system_prompt},
#         {"role": "user", "content": f"{curr_user_query_ctx.get().strip()}"}
#     ]



def build_key_prompt(raw_query: str):
    # Dynamically get keys from context
    index_list = index_list_ctx.get([])   # e.g., ["project_name", "days", "organization_name"]
    print("index_list:", index_list)

    # Safety: fallback to empty if nothing provided
    if not index_list:
        index_list = []

    # Build schema string
    schema_str = ", ".join([f'"{k}"' for k in index_list])

    key_prompt = f"""
You are a JSON extractor assistant designed to analyze natural language queries and extract key business-related entities dynamically.

Your task is:
- If the question is related to "Rodic" or "Group", do not extract any values for these keys. In that case, set them to null.
- Analyze the following input query carefully.
- Identify if any of these keys are mentioned (explicitly or implicitly):
    {", ".join(index_list)}
- For each key, extract its value as a string (or number for days).  
- If a key is not mentioned or cannot be confidently extracted, assign it a value of null.

**Output requirements:**
- Your entire output must be a JSON object with exactly these keys: {schema_str}.
- Do NOT include any additional text, explanation, or formatting.
- Output only valid JSON.

### Input Query:
\"\"\"{raw_query}\"\"\"

### Output JSON:
"""

    return [
        {"role": "system", "content": key_prompt},
        {"role": "user", "content": raw_query}
    ]




import json

def build_refiner_prompt(**kwargs) -> list:
    # Helper: clean list from None, empty, 'none' etc
    def clean_list(results):
        if results is not None:
            return list(set([str(r).strip() for r in results if r and str(r).strip().lower() != "none"]))
        else:
            return []

    cleaned_data = {}
    display_strings = {}

    # 🔹 Loop over all dynamic keys
    for key, value in kwargs.items():
        valid_list = clean_list(value)
        cleaned_data[key] = valid_list
        display_strings[key] = ", ".join(valid_list) if valid_list else "None"

    # ⚡ पहले summary_lines था, अब index_lines
    index_lines = [f"{k}: {v}" for k, v in display_strings.items()]
    index_text = "\n".join(index_lines)
    print("Cleaned Data Index View:\n", index_text)

    # Contexts
    history_formatted = json.dumps(chat_history_ctx.get(), indent=2)
    schema_str = retrieved_db_schema_for_query_ctx.get().strip()
    db_name = database_detail_ctx.get().get("label_name", "").strip().lower()
    print("label name", db_name)
    current_query = curr_user_query_ctx.get().strip()

    # 🔹 System prompt with index_text
    system_prompt = f"""# Section 1: Persona & Core Task
You are a highly capable query refinement assistant in a production-grade analytics system.
Your primary goal is to analyze the user's current natural language query, considering the chat history and database information context provided below, and rewrite it into one or more clear, unambiguous, detailed, and self-contained natural language questions suitable for a downstream SQL generation component.
**Your output MUST be a valid JSON object with the fields `count` and `queries`. No explanation, no extra text. Only the JSON object.**

# Section 2: Input Context Explanation
You will receive the following inputs:
* **Current User Query:** The latest natural language query from the user (provided as the main input).
* **Chat History:** A list of previous user interactions (newest first), potentially empty. Use this history to understand context, follow-ups, and references to previous results.
* **Database Information:** Detailed information about tables, columns, descriptions, and example values. Use this to understand data structure and content formats.

# Section 3: Provided Inputs
--- Chat History (Newest First) ---
{history_formatted}
# --- End Chat History ---

--- Database Information ---
{schema_str}
# --- End Database Schema ---

# Section 4: Recognized Entities for Refinement
You have lists of relevant entities extracted from prior context:
{index_text}

# Section 5: Analysis and Refinement Instructions
For the CURRENT User Query, perform the following steps:
1. Carefully analyze the CURRENT User Query to detect any mentions or references to recognized entities (keys listed above).
   - This detection should include exact matches, partial matches, fuzzy/approximate matches, and semantic similarity.
2. If the CURRENT User Query contains any mention or reference (direct or indirect) to any recognized entity:
   a. Identify **all relevant full names** from the provided lists that are similar or related to those mentions.
   b. Generate a **single, clear, detailed, and self-contained refined natural language question** that:
      - Fully reflects the original intent of the user's query.
      - Replaces all mentions with the **full, detailed, and complete names from the entity lists**, including all similar or relevant names.
      - Ensures no partial, ambiguous, or abbreviated names remain.
3. If the CURRENT User Query does **not** mention or relate to any recognized entity, generate a refined question purely based on the original query intent **without adding any entity names**.
4. If the user query involves financial terms such as "outstanding amount","debtor balance", "balance", "due", "receivable", "pending payment", or similar, analyze the query to determine its **time context**:
   - Do not add "current" or "old" if no time context is implied.
   - If the query is **currency-wise** (mentions "currency-wise", "with currency", or "in transaction currency") and has **no time reference**, then **do not add any mention of current or old**.
5. If the database name is `{db_name}` and it equals `rodic_contracts`, then ensure that the refined query **always includes the word "unique"** wherever appropriate — especially when referring to issue identifiers, transactions, or rows.

# Section 6: Output Format Specification
--- Output Format ---
Return a **valid JSON object** in the following structure:

{{
  "count": [number of refined queries],
  "queries": [
    "Refined query one...",
    "Refined query two if needed..."
  ]
}}

**DO NOT include any markdown formatting, explanation, labels, or additional keys. The entire response must be only this JSON object.**
"""

    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": current_query.strip()}
    ]



# ✅ Query Response Parser

# def parse_refined_response(response: str) -> tuple[int, list]:
#     refined_queries = []
#     count = 0

#     match = re.search(r"count:\s*(\d+)\nqueries:\n([\s\S]*)", response, re.IGNORECASE)
#     if match:
#         try:
#             count = int(match.group(1))
#             queries_text = match.group(2).strip()
#             if count > 0 and queries_text:
#                 lines = [
#                     q.strip().lstrip('-').strip() for q in queries_text.split('\n') if q.strip()
#                 ]
#                 if any(any(keyword in q.upper() for keyword in ['SELECT ', 'DELETE ', 'INSERT ', 'DROP ']) for q in lines):
#                     print("❌ LLM returned SQL instead of NL queries. Fallback to raw.")
#                 else:
#                     refined_queries = lines
#                     if len(refined_queries) != count:
#                         print(f"⚠️ Mismatch in count. Declared: {count}, Parsed: {len(refined_queries)}")
#         except Exception as e:
#             print(f"❌ Error parsing query count/lines: {e}")
#     else:
#         print("⚠️ Pattern 'count: ... queries:' not found. Returning empty results.")

#     return count, refined_queries