# API Documentation for Intelligent SQL Query Service

## Endpoints

### 1. `/api/connect-db` (POST)
Establishes a database connection.
#test
**Request:**
```json
{
  "auth": {
    "api_key": "xyz789"
  },
  "data": {
    "database_detail": {
      "host": "localhost",
      "port": 1433,
      "username": "SAB",
      "password": "vocso@2025",
      "database_name": "rodic-bi",
      "database_type": "mssql"
    }
  }
}
```

**Response:**
```json
{
    "auth": {
        "api_key": "xyz789"
    },
    "status": "success",
    "code": 200,
    "message": "Database connection successfully established.",
    "data": {
        "dbname": "rodic-bi"
    }
}
```

---

### 2. `/api/get-tables` (POST)
Fetches available tables from the database.

**Request:**
```json
{
  "auth": {
    "api_key": "xyz789"
  },
  "data": {
    "database_detail": {
      "host": "localhost",
      "port": 1433,
      "username": "SA",
      "password": "vocso@2025",
      "database_name": "rodic-bi",
      "database_type": "mssql"
    }
  }
}
```

**Response:**
```json
{
    "auth": {
        "api_key": "xyz789"
    },
    "status": "success",
    "code": 200,
    "message": "Fetched tables successfully.",
    "data": {
        "tables": [
            "custtable",
            "projtable",
            "custtrans"
        ]
    }
}
```

---

### 3. `/api/get-schemas` (POST)
Fetches schemas for specific tables.

**Request:**
```json
{
  "auth": {
    "api_key": "xyz789"
  },
  "data": {
    "database_detail": {
      "host": "localhost",
      "port": 1433,
      "username": "SA",
      "password": "vocso@2025",
      "database_name": "rodic-bi",
      "database_type": "mssql"
    },
    "table_names": ["custtable", "projtable"]
  }
}
```

**Response:**
```json
{
    "auth": {
        "api_key": "xyz789"
    },
    "status": "success",
    "code": 200,
    "message": "Fetched schema for multiple tables.",
    "data": {
        "tables": {
            "custtable": [
                {
                    "column_name": "customeraccount",
                    "data_type": "varchar"
                },
                {
                    "column_name": "payment_terms_base_days",
                    "data_type": "smallint"
                },
                {
                    "column_name": "address_city",
                    "data_type": "varchar"
                },
                {
                    "column_name": "full_primary_address",
                    "data_type": "text"
                },
                {
                    "column_name": "address_state",
                    "data_type": "varchar"
                },
                {
                    "column_name": "organization_name",
                    "data_type": "varchar"
                },
                {
                    "column_name": "pan_status",
                    "data_type": "varchar"
                },
                {
                    "column_name": "address_country_regioniso_code",
                    "data_type": "varchar"
                },
                {
                    "column_name": "customer_groupid",
                    "data_type": "varchar"
                },
                {
                    "column_name": "address_description",
                    "data_type": "varchar"
                },
                {
                    "column_name": "nature_of_assessee",
                    "data_type": "varchar"
                },
                {
                    "column_name": "address_street",
                    "data_type": "varchar"
                },
                {
                    "column_name": "state_ut",
                    "data_type": "varchar"
                },
                {
                    "column_name": "party_type",
                    "data_type": "varchar"
                },
                {
                    "column_name": "address_zip_code",
                    "data_type": "varchar"
                }
            ],
            "projtable": [
                {
                    "column_name": "parent_project_id",
                    "data_type": "varchar"
                },
                {
                    "column_name": "customer_account",
                    "data_type": "varchar"
                },
                {
                    "column_name": "projectname",
                    "data_type": "varchar"
                },
                {
                    "column_name": "worker_responsible_personnel_number",
                    "data_type": "varchar"
                },
                {
                    "column_name": "business_line_name",
                    "data_type": "varchar"
                },
                {
                    "column_name": "dimensiondisplay_value_1",
                    "data_type": "varchar"
                },
                {
                    "column_name": "region",
                    "data_type": "varchar"
                }
            ]
        }
    }
}
```

---

### 4. `/api/generate-embeddings-all` (POST)
Generates embeddings for all tables.

**Request:**
```json
{
  "auth": {
    "api_key": "xyz789"
  },
  "data": {
    "database_detail": {
      "host": "localhost",
      "port": 1433,
      "username": "SA",
      "password": "vocso@2025",
      "database_name": "rodic-bi",
      "database_type": "mssql"
    },
    "tables": [
      {
        "table_name": "projtable",
        "table_description": "All project related details",
        "column_descriptions": {
          "projectname": "Name of the project",
          "business_line_name": "Business field associated"
        }
      },
      {
        "table_name": "custtable",
        "table_description": "Customer details",
        "column_descriptions": {
          "pan_status": "PAN status of the customer",
          "state_ut": "State or UT location"
        }
      }
    ]
  },
  "options": {
    "include_sample_values": true,
    "sample_value_limit": 4
  }
}
```

**Response:**
```json
{
    "auth": {
        "api_key": "success"
    },
    "status": "Metadata and FAISS index generated using DB name: rodic_bi",
    "code": 200,
    "message": 200,
    "data": {
        "metadata_file": "db_schema_embeddings/mssql/rodic_bi/db_schema.txt",
        "index_file": "db_schema_embeddings/mssql/rodic_bi/db_schema_embedding.index",
        "total_tables": 3,
        "total_columns": 29
    }
}
```

---

### 5. `/api/generate-embeddings-selected` (POST)
Generates embeddings for selected tables.

**Request:**
```json
{
  "auth": {
    "api_key": "xyz789"
  },
  "data": {
    "database_detail": {
      "host": "localhost",
      "port": 1433,
      "username": "SA",
      "password": "vocso@2025",
      "database_name": "rodic-bi",
      "database_type": "mssql"
    },
    "tables": [
      {
        "table_name": "projtable",
        "table_description": "All project related details",
        "column_descriptions": {
          "projectname": "Name of the project",
          "business_line_name": "Business field associated"
        }
      },
      {
        "table_name": "custtable",
        "table_description": "Customer details",
        "column_descriptions": {
          "pan_status": "PAN status of the customer",
          "state_ut": "State or UT location"
        }
      },
      {
        "table_name": "custtrans",
        "table_description": "All project related details",
        "column_descriptions": {
          "projectname": "Name of the project",
          "business_line_name": "Business field associated"
        }
      }
    ]
  },
  "options": {
    "include_sample_values": true,
    "sample_value_limit": 4
  }
}
```

**Response:**
```json
{
  "auth": {"api_key": "xyz789"},
  "status": "Metadata and FAISS index generated using DB name: rodic_bi",
  "code": 200,
  "message": 200,
  "data": {
    "metadata_file": "db_schema_embeddings/mssql/rodic_bi/db_schema.txt",
    "index_file": "db_schema_embeddings/mssql/rodic_bi/db_schema_embedding.index",
    "total_tables": 2,
    "total_columns": 20
  }
}
```

---

### 6. `/api/ask-query` (POST)
Submits a user query with chat history and returns SQL insights.

**Request:**
```json
{
  "auth": {
    "api_key": "xyz789"
  },
  "options": {
    "set_any_params": false
  },
  "data": {
    "chat_history": [
      {
        "original_query": "Show all employees",
        "total_refined_query": 2,
        "refined_query_list": [
          "List all employee details",
          "Fetch employee names and departments"
        ],
        "query_sql_answer": [
          {
            "refined_query": "List all employee details",
            "generated_sql": "SELECT * FROM employees",
            "executed_sql_output": [
              { "name": "John", "role": "Manager" },
              { "name": "Alice", "role": "HR Executive" }
            ],
            "remarks": "Initial list of all employees"
          },
          {
            "refined_query": "Fetch employee names and departments",
            "generated_sql": "SELECT name, department FROM employees",
            "executed_sql_output": [
              { "name": "John", "department": "Management" },
              { "name": "Alice", "department": "HR" }
            ],
            "remarks": "Filtered for department view"
          }
        ],
        "summary": "Listed all employees with names and departments"
      },
      {
        "original_query": "Top selling products?",
        "total_refined_query": 1,
        "refined_query_list": [
          "Get top 5 selling products"
        ]
      }
    ],
    "curr_user_query": "total project of bihar",
    "database_detail": {
      "database_type": "mssql",
      "database_name": "rodic-bi",
      "host": "localhost",
      "port": "1433",
      "username": "SA",
      "password": "vocso@2025",
      "driver": "{ODBC Driver 17 for SQL Server}"
    },
    "AIModel": {
      "name": "gpt-4o",
      "platform": "openai",
      "api_key": "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"
    }
  }
}
```

**Response:**
```json
{
    "auth": {
        "api_key": "xyz789"
    },
    "status": "success",
    "code": 200,
    "message": "Request successful.",
    "data": {
        "original_query": "total project of bihar and its total transaction",
        "total_refined_query": 2,
        "refined_query_list": [
            "What is the total number of projects in Bihar?",
            "What is the total transaction amount for all projects in Bihar?"
        ],
        "query_sql_answer": [
            {
                "refined_query": "What is the total number of projects in Bihar?",
                "generated_sql": "SELECT COUNT(pt.parent_project_id) \n  FROM projtable pt \n  INNER JOIN custtable ct ON pt.customer_account = ct.customeraccount \n  WHERE ct.address_state = 'BR'",
                "executed_sql_output": [
                    {
                        "total_project": 45
                    }
                ],
                "remarks": ""
            },
            {
                "refined_query": "What is the total transaction amount for all projects in Bihar?",
                "generated_sql": "SELECT SUM(ct.amountcur) \n  FROM custtrans ct \n  JOIN projtable pt ON ct.accountnum = pt.customer_account \n  JOIN custtable c ON pt.customer_account = c.customeraccount \n  WHERE c.address_state = 'Bihar' OR c.state_ut = 'Bihar'",
                "executed_sql_output": [
                    {
                        "total_transaction": "1754744052.00"
                    }
                ],
                "remarks": ""
            }
        ],
        "summary": "Summary:\nThe original query was broken down into two parts to analyze the total project and total transaction in Bihar. The key findings show that there are a significant number of projects in Bihar, totaling 45, and the total transaction amount for all projects is substantial, amounting to 1754744052.00. \n\nDescription of Result:\n- Query 1:\n  - Step 1: The process began by identifying the requirement to count the total number of projects in Bihar.\n  - Step 2: The system then linked the relevant information about projects and customers to determine the location of each project.\n  - Step 3: It filtered the projects to only include those located in Bihar.\n  - Step 4: Finally, the system calculated the total count of projects in Bihar, resulting in 45 projects.\n  - Assumptions: It was assumed that the state of Bihar is abbreviated as 'BR' in the customer address.\n- Query 2:\n  - Step 1: The process started by identifying the need to calculate the total transaction amount for all projects in Bihar.\n  - Step 2: The system then connected the relevant transaction, project, and customer data to determine the amount of each transaction.\n  - Step 3: It filtered the transactions to only include those associated with projects in Bihar, regardless of whether Bihar is listed as the state or union territory.\n  - Step 4: Finally, the system summed up the transaction amounts for all projects in Bihar, resulting in a total of 1754744052.00.\n  - Assumptions: It was assumed that the state of Bihar can be represented as either 'Bihar' or 'BR' in the customer address and that the transaction amount is stored in the 'amountcur' field.\n\nMistake Point:\n- Query 1: No mistakes detected.\n- Query 2: No mistakes detected, but potential issue might arise if the state 'Bihar' has different representations or abbreviations in the data beyond 'Bihar' or 'BR', which could affect the accuracy of the results."
    }
}
```


### 7. `/api/ask-query-chunk-response` (POST)
Submits a user query with chat history and returns SQL insights.


**Request:**
```json
{
  "auth": {
    "api_key": "xyz789"
  },
  "options": {
    "set_any_params": false
  },
  "data": {
    "chat_history": [
      {
        "original_query": "Show all employees",
        "total_refined_query": 2,
        "refined_query_list": [
          "List all employee details",
          "Fetch employee names and departments"
        ],
        "query_sql_answer": [
          {
            "refined_query": "List all employee details",
            "generated_sql": "SELECT * FROM employees",
            "executed_sql_output": [
              { "name": "John", "role": "Manager" },
              { "name": "Alice", "role": "HR Executive" }
            ],
            "remarks": "Initial list of all employees"
          },
          {
            "refined_query": "Fetch employee names and departments",
            "generated_sql": "SELECT name, department FROM employees",
            "executed_sql_output": [
              { "name": "John", "department": "Management" },
              { "name": "Alice", "department": "HR" }
            ],
            "remarks": "Filtered for department view"
          }
        ],
        "summary": "Listed all employees with names and departments"
      },
      {
        "original_query": "Top selling products?",
        "total_refined_query": 1,
        "refined_query_list": [
          "Get top 5 selling products"
        ]
      }
    ],
    "curr_user_query": "give me total project of bihar and total tarnsaction amount of gurgaon",
    "database_detail": {
      "database_type": "mssql",
      "database_name": "rodic-bi",
      "host": "localhost",
      "port": "1433",
      "username": "SA",
      "password": "vocso@2025",
      "driver": "{ODBC Driver 17 for SQL Server}"
    },
    "AIModel": {
      "name": "gpt-4o",
      "platform": "openai",
      "api_key": "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"
    }
  }
}
```

**Response:**
Each success message is chunk response and simillar way error response will be

```json
{
  "status": "success",
  "code": 200,
  "message": "Request successful.",
  "data": {
    "refined_query": "What is the total number of projects in the state of Bihar?"
  }
}
{
  "status": "success",
  "code": 200,
  "message": "Request successful.",
  "data": {
    "generated_sql": "SELECT COUNT(DISTINCT pt.parent_project_id) AS total_projects FROM projtable pt INNER JOIN custtable ct WITH (NOLOCK) ON pt.customer_account = ct.customeraccount WHERE ct.address_state = 'BR'",
    "executed_sql_output": "[{'total_projects': 45}]"
  }
}
{
  "status": "success",
  "code": 200,
  "message": "Request successful.",
  "data": {
    "refined_query": "What is the total transaction amount for the city of Gurgaon?"
  }
}
{
  "status": "success",
  "code": 200,
  "message": "Request successful.",
  "data": {
    "generated_sql": "SELECT SUM(custtrans.amountcur) AS total_amount FROM custtable INNER JOIN custtrans ON custtable.customeraccount = custtrans.accountnum WHERE custtable.address_city = 'Gurgaon'",
    "executed_sql_output": "[{'total_amount': '17148547.00'}]"
  }
}
{
  "status": "success",
  "code": 200,
  "message": "Request successful.",
  "data": {
    "summary": "The state of Bihar has a total of 45 projects. In the city of Gurgaon, the total transaction amount is 17148547.00."
  }
}
```