from __future__ import annotations
from fastapi import FastAPI, Request, HTTPException, Depends
from pydantic import BaseModel
from typing import Dict, List, Optional, Union
import psycopg2
import pyodbc  # MSSQL connection
import faiss
import numpy as np
import json
import datetime
from decimal import Decimal
from pathlib import Path
from sentence_transformers import SentenceTransformer 
from typing import Dict, Any, AsyncGenerator
import html as html_lib
# testing
from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from context_middleware import ResetContextMiddleware
from security_keys.req_res_keys import auth_keys
from database import connect_mssql, connect_postgres
from test_llm_conn import test_llm_connection
import time, os
import asyncio
from fastapi import Body
from fastapi.responses import JSONResponse ,Response
import traceback
from starlette.middleware.cors import CORSMiddleware
from starlette.responses import StreamingResponse
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from elastic_search import create_index_only, update_index
from elasticsearch import Elasticsearch
from dotenv import load_dotenv

load_dotenv()


from context import (
    chat_history_ctx, curr_user_query_ctx,index_list_ctx,
    database_detail_ctx, retrieved_db_schema_for_query_ctx,
    main_model_ctx, summary_model_ctx, sql_gen_model_ctx,
    query_refiner_model_ctx,  # Correct import as per your note.
    error_correction_model_ctx, error_summary_model_ctx, 
    unspecialized_model_ctx, query_response_ctx, fastapi_response_ctx
)

from main import process_query, process_query_chunk_response
from db_schema_embeddings_load_in_ram import embeddings_in_ram, scan_and_load_db_schema_embeddings_in_ram, load_db_embeddings_in_ram 

from logger_utils import log_retrieved_response, log_retrieved_payload


# Check the validity of the API Key
async def verify_api_key(request: Request):
    # Only check API key for methods that have a body (POST, PUT, PATCH)
    if request.method in ("POST", "PUT", "PATCH"):
        try:
            body = await request.json()
            api_key = body.get("auth", {}).get("api_key")
            if api_key not in VALID_API_KEYS:
                raise HTTPException(status_code=403, detail="Invalid or missing API key")
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid request format")

app = FastAPI(title="Your Main App", dependencies=[Depends(verify_api_key)])




# Load the embedding model (same one used for generating embeddings)
embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

# Store the embedding model in embeddings_in_ram["models"]
embeddings_in_ram["models"].append(embedding_model)

# Scan and load the DB schema embeddings from the folder structure
scan_and_load_db_schema_embeddings_in_ram()





# Replace the `load_valid_keys` function to use the imported `auth_keys`
def load_valid_keys() -> list:
    try:
        # Fetching keys directly from the imported `auth_keys` object
        return auth_keys.get("all_keys", [])
    except Exception as e:
        raise RuntimeError(f"Error loading keys: {str(e)}")

VALID_API_KEYS = load_valid_keys()

# Check the validity of the API Key
async def verify_api_key(request: Request):
    try:
        body = await request.json()
        api_key = body.get("auth", {}).get("api_key")
        if api_key not in VALID_API_KEYS:
            raise HTTPException(status_code=403, detail="Invalid or missing API key")
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid request format")

app.add_middleware(ResetContextMiddleware)
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

# Request Models
class AuthBlock(BaseModel):
    api_key: str

# 🔐 2. Basic DB connection details
class DBAttributes(BaseModel):
    host: str
    port: int
    username: str
    password: str
    database_name: str
    database_type: str  # "postgres" or "mssql"

# 🔐 3. Wrapper for DB attributes
class WrapperAttributes(BaseModel):
    database_detail: DBAttributes

# 🔐 4. For basic DB connection
class ConnectPayload(BaseModel):
    auth: AuthBlock
    data: WrapperAttributes

# 🔐 5. Table & view names list for fetching schema
class TableListAttributes(WrapperAttributes):
    table_names: List[str]
    view_names: Optional[List[str]] = []

class GetSchemasPayload(BaseModel):
    auth: AuthBlock
    data: TableListAttributes

# ✅ 6. Column description with optional alias support
class ColumnDescription(BaseModel):
    alias: Optional[str] = None
    description: str

# ✅ 7. Table description with alias support
class TableDescription(BaseModel):
    table_name: str
    table_description: str
    table_alias: Optional[str] = None
    # This line allows both:
    # - "column_name": "plain description"
    # - "column_name": {"alias": "...", "description": "..."}
    column_descriptions: Dict[str, Union[str, ColumnDescription]]

# ✅ 8. Attributes for embedding: tables + views
class EmbeddingAttributes(WrapperAttributes):
    label_name: str
    tables: List[TableDescription]
    views: Optional[List[TableDescription]] = []

# ✅ 9. Options for sample value embedding
class GenerateOptions(BaseModel):
    include_sample_values: bool = True
    sample_value_limit: int = 5

# ✅ 10. Final payload model for /generate-embeddings-selected
class GenerateEmbeddingsPayload(BaseModel):
    auth: AuthBlock
    data: EmbeddingAttributes
    options: Optional[GenerateOptions] = GenerateOptions()

# 🔐 11. For business rules (non-schema use case)
class businessDescription(BaseModel):
    title: str
    description: str
    priority: str

class businessAttributes(BaseModel):
    database_type: str  # "postgres" या "mssql"
    label_name: str

class Embeddingbusiness(BaseModel):
    database_detail: businessAttributes
    tables: List[businessDescription]

class GenerateBusinessEmbeddings(BaseModel):
    auth: AuthBlock
    data: Embeddingbusiness

class DBQueryInner(BaseModel):
    database_detail: DBAttributes
    query: str

class DBQueryPayload(BaseModel):
    auth: AuthBlock
    data: DBQueryInner

class DatabaseDetail(BaseModel):
    host: str
    port: int
    username: str
    password: str
    database_name: str
    database_type: str
    label_name: str

class SearchData(BaseModel):
    index_name: str
    table: str
    column: str


class DataWrapper(BaseModel):
    database_detail: DatabaseDetail
    search_data: SearchData

class PayloadIndex(BaseModel):
    auth: AuthBlock
    data: DataWrapper
    

# Connection function
def connect_db(params: DBAttributes):
    if params.database_type == "postgres":
        # PostgreSQL connection
        return psycopg2.connect(
            host=params.host,
            port=params.port,
            user=params.username,
            password=params.password,
            dbname=params.database_name
        )
    elif params.database_type == "mssql":
        # MSSQL connection
        conn_str = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={params.host},{params.port};DATABASE={params.database_name};UID={params.username};PWD={params.password}'
        return pyodbc.connect(conn_str)
    else:
        raise HTTPException(status_code=400, detail="Unsupported database type")

# Normalize data function
def normalize(value):
    if value is None:
        return None
    elif isinstance(value, str):
        return value.strip().replace("\n", " ").replace("\r", " ")
    return str(value)

# Folder creation function
def create_db_folder(db_name: str) -> Path:
    # Define a base directory where database folders will be stored
    base_dir = Path("db_schema_embeddings")  # You can change the base directory as per your requirement
    
    # Ensure the base directory exists
    base_dir.mkdir(parents=True, exist_ok=True)
    
    # Create a directory for the specific database
    db_folder = base_dir / db_name
    db_folder.mkdir(parents=True, exist_ok=True)  # This will create the folder if it doesn't exist
    
    return db_folder

# API response structure
def api_response(auth_api_key, status: str, message: str, code: int = 200, data=None):
    return {
        "auth": {"api_key": auth_api_key},  # Replace with actual API key if needed
        "status": status,
        "code": code,
        "message": message,
        "data": data
    }


# Elasticsearch connection
es = Elasticsearch(
    os.getenv("ELASTICSEARCH_HOST"),
    basic_auth=("elastic", os.getenv("ELASTICSEARCH_PASSWORD")),
    ca_certs=os.getenv("ELASTICSEARCH_CA_CERT"),
)

# Request body model
class DeleteData(BaseModel):
    index_names: List[str]

class DeleteIndexRequest(BaseModel):
    auth: AuthBlock
    data: DeleteData


# ---------------------
# Delete Index API
# ---------------------
@app.delete("/api/delete_index")
async def delete_indexes(request: DeleteIndexRequest):
    deleted = []
    not_found = []
    errors = []

    for index_name in request.data.index_names:
        try:
            if not es.indices.exists(index=index_name):
                not_found.append(index_name)
                continue
            es.indices.delete(index=index_name)
            deleted.append(index_name)
        except Exception as e:
            errors.append({index_name: str(e)})

    # Decide message dynamically
    if deleted and not not_found and not errors:
        message = "Indexes deleted successfully."
    elif not deleted and not_found and not errors:
        message = "No indexes deleted. All requested indexes were not found."
    elif errors:
        message = "Some errors occurred while deleting indexes."
    else:
        message = "Indexes deleted with partial success."

    return api_response(
        auth_api_key=request.auth.api_key,
        status="success" if not errors else "failed",
        message=message,
        code=200 if not errors else 500,
        data={
            "deleted": deleted,
            "not_found": not_found,
            "errors": errors
        }
    )



class ListIndexRequest(BaseModel):
    auth: AuthBlock

@app.post("/api/list_index")
async def list_indexes(request: ListIndexRequest):
    try:
        all_indices = es.cat.indices(format="json")
        index_names = [idx["index"] for idx in all_indices]

        return api_response(
            auth_api_key=request.auth.api_key,
            status="success",
            message="Fetched all indexes successfully.",
            code=200,
            data={"indexes": index_names}
        )
    except Exception as e:
        return api_response(
            auth_api_key=request.auth.api_key,
            status="error",
            message=str(e),
            code=500,
            data=None
        )



@app.post("/api/create_index")
def api_create_index(payload: PayloadIndex):
    try:
        result = create_index_only(
            payload.data.database_detail.dict(),
            payload.data.search_data.dict()
        )
        return api_response(
            auth_api_key=payload.auth.api_key,
            status="success",
            message=result.get("message"),
            code=200,
            data={"documents_indexed": result.get("documents_indexed")}
        )
    except Exception as e:
        return api_response(
            auth_api_key=payload.auth.api_key,
            status="error",
            message=str(e),
            code=500,
            data=None
        )



@app.post("/api/update_index")
def api_update_index(payload: PayloadIndex):
    try:
        result = update_index(
            payload.data.database_detail.dict(),
            payload.data.search_data.dict()
        )
        return api_response(
            auth_api_key=payload.auth.api_key,
            status="success",
            message=result.get("message"),
            code=200,
            data={"documents_indexed": result.get("documents_indexed")}
        )
    except Exception as e:
        return api_response(
            auth_api_key=payload.auth.api_key,
            status="error",
            message=str(e),
            code=500,
            data=None
        )



# API endpoint to connect to the database
@app.post("/api/connect-db")
def connect_database(payload: ConnectPayload):
    try:
        db_config = payload.data.database_detail  # Updated to access 'data' and 'database_detail'
        _ = connect_db(db_config)
        return api_response(payload.auth.api_key, "success", "Database connection successfully established.", data={"dbname": db_config.database_name})
    except Exception as e:
        return api_response(payload.auth.api_key, "error", str(e), 500, data=None)

# API endpoint to fetch tables from the database
@app.post("/api/get-tables")
def fetch_tables(payload: ConnectPayload):
    try:
        db_config = payload.data.database_detail
        conn = connect_db(db_config)
        with conn.cursor() as cur:
            if db_config.database_type.lower() == "mssql":
                # Fetch tables from dbo schema
                cur.execute("""
                    SELECT table_name 
                    FROM information_schema.tables
                    WHERE table_schema = 'dbo' AND table_type = 'BASE TABLE'
                """)
                tables = [row[0] for row in cur.fetchall()]
                
                # Fetch views from dbo schema
                cur.execute("""
                    SELECT table_name
                    FROM information_schema.views
                    WHERE table_schema = 'dbo'
                """)
                views = [row[0] for row in cur.fetchall()]
            else:
                # For PostgreSQL, fetch only tables from public schema
                cur.execute("""
                    SELECT table_name 
                    FROM information_schema.tables 
                    WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
                """)
                tables = [row[0] for row in cur.fetchall()]
                views = []  # No views for PostgreSQL in this case

        return api_response(
            payload.auth.api_key,
            "success",
            "Fetched tables and views successfully.",
            data={"tables": tables, "views": views}
        )
    except Exception as e:
        return api_response(payload.auth.api_key, "error", str(e), 500, data=None)


# API endpoint to fetch schema information for multiple tables
@app.post("/api/get-schemas")
def get_multiple_table_info(payload: GetSchemasPayload):
    try:
        db_config = payload.data.database_detail
        conn = connect_db(db_config)
        
        tables_result = {}
        views_result = {}

        with conn.cursor() as cur:
            if db_config.database_type.lower() == "mssql":
                # Fetch schema for tables
                for table in payload.data.table_names:
                    cur.execute("""
                        SELECT column_name, data_type
                        FROM information_schema.columns
                        WHERE table_schema = 'dbo' AND table_name = ?
                    """, (table,))
                    columns = [{"column_name": row[0], "data_type": row[1]} for row in cur.fetchall()]
                    tables_result[table] = columns
                
                # Fetch schema for views
                for view in payload.data.view_names:
                    cur.execute("""
                        SELECT column_name, data_type
                        FROM information_schema.columns
                        WHERE table_schema = 'dbo' AND table_name = ?
                    """, (view,))
                    columns = [{"column_name": row[0], "data_type": row[1]} for row in cur.fetchall()]
                    views_result[view] = columns

            else:
                # PostgreSQL: only tables (assuming views not requested)
                for table in payload.data.table_names:
                    cur.execute("""
                        SELECT column_name, data_type
                        FROM information_schema.columns
                        WHERE table_schema = 'public' AND table_name = %s
                    """, (table,))
                    columns = [{"column_name": row[0], "data_type": row[1]} for row in cur.fetchall()]
                    tables_result[table] = columns
                views_result = {}

        return api_response(
            payload.auth.api_key,
            "success",
            "Fetched schema for multiple tables and views.",
            200,
            data={
                "tables": tables_result,
                "views": views_result
            }
        )
    except Exception as e:
        return api_response(payload.auth.api_key, "error", str(e), 500, data=None)


@app.post("/api/get-db-data")
async def get_db_data(payload: DBQueryPayload):
    db_info = payload.data.database_detail
    query = payload.data.query

    if not query:
        return api_response(payload.auth.api_key, "error", "Query is missing in payload", 400)

    try:
        # ✅ Connect to the correct database
        if db_info.database_type.lower() == "mssql":
            conn_str = (
                f"DRIVER={{ODBC Driver 17 for SQL Server}};"
                f"SERVER={db_info.host},{db_info.port};"
                f"DATABASE={db_info.database_name};"
                f"UID={db_info.username};"
                f"PWD={db_info.password};"
            )
            conn = pyodbc.connect(conn_str)

        elif db_info.database_type.lower() == "postgres":
            conn = psycopg2.connect(
                host=db_info.host,
                port=db_info.port,
                database=db_info.database_name,
                user=db_info.username,
                password=db_info.password
            )

        else:
            return api_response(payload.auth.api_key, "error", "Unsupported database type", 400)

        cursor = conn.cursor()
        cursor.execute(query)

        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()

        # ✅ Serialize row to handle datetime and decimal
        def serialize_row(row):
            return [
                value.isoformat() if isinstance(value, (datetime.date, datetime.datetime)) else
                float(value) if isinstance(value, Decimal) else
                value
                for value in row
            ]

        results = [dict(zip(columns, serialize_row(row))) for row in rows]

        cursor.close()
        conn.close()

        return api_response(
            payload.auth.api_key,
            "success",
            "Query executed successfully.",
            code=200,
            data={
                "records": results,
                "row_count": len(results),
                "database": db_info.database_name
            }
        )

    except Exception as e:
        return api_response(
            payload.auth.api_key,
            "error",
            "Query execution failed.",
            code=500,
            data={
                "error": str(e),
                "trace": traceback.format_exc()
            }
        )

@app.post("/api/generate_embedding_business_rules")
def generate_embedding_business_rules(payload: GenerateBusinessEmbeddings):
    try:
        db_type = payload.data.database_detail.database_type.lower()
        label_name = payload.data.database_detail.label_name

        base_folder = Path("db_schema_embeddings") / db_type
        base_folder.mkdir(parents=True, exist_ok=True)
        type_folder = base_folder / label_name
        type_folder.mkdir(parents=True, exist_ok=True)

        metadata_filename = type_folder / "business_schema.txt"
        index_filename = type_folder / "business_embedding.index"

        # Prepare the data for embeddings
        titles = [item.title for item in payload.data.tables]
        descriptions = [item.description for item in payload.data.tables]
        priorities = [item.priority for item in payload.data.tables]

        # Prepare the metadata lines to be saved
        metadata_lines = []
        for title, description, priority in zip(titles, descriptions, priorities):
            meta = f"Title: {title}, Description: {description}, Priority: {priority}"
            metadata_lines.append(meta)

        # Write metadata to file
        with open(metadata_filename, "w", encoding="utf-8") as f:
            for meta in metadata_lines:
                f.write(meta + "\n")

        # Generate embeddings for metadata lines
        embedding_texts = metadata_lines
        embeddings = np.array([embedding_model.encode(text, convert_to_numpy=True).astype(np.float32) for text in embedding_texts])

        # Create and save FAISS index
        index = faiss.IndexFlatL2(embeddings.shape[1])  # L2 distance metric
        index.add(embeddings)
        faiss.write_index(index, str(index_filename))

        time.sleep(5)

        load_db_embeddings_in_ram(db_type, label_name)

        return api_response(
            payload.auth.api_key,
            "success",
            f"Metadata and FAISS index generated successfully",
            200,
            data={
                "metadata_file": str(metadata_filename),
                "index_file": str(index_filename),
                
            },
        )

    except Exception as e:
        return api_response(payload.auth.api_key, "error", str(e), 500, data=None)





    
@app.post("/api/generate-embeddings-selected")
def generate_schema_selected(payload: GenerateEmbeddingsPayload):
    try:
        include_sample_values = payload.options.include_sample_values
        sample_value_limit = payload.options.sample_value_limit
        db_name = payload.data.database_detail.database_name.lower().replace(" ", "_").replace("-", "_")
        db_type = payload.data.database_detail.database_type.lower()
        label_name = payload.data.label_name

        base_folder = Path("db_schema_embeddings") / db_type
        base_folder.mkdir(parents=True, exist_ok=True)
        type_folder = base_folder / label_name
        type_folder.mkdir(parents=True, exist_ok=True)

        metadata_filename = type_folder / "db_schema.txt"
        index_filename = type_folder / "db_schema_embedding.index"

        table_desc_map = {}
        column_desc_map = {}
        relationship_lines = []
        metadata_lines = []

        def process_entities(entities):
            for e in entities:
                t_alias = getattr(e, "table_alias", None)
                table_desc = f"Also known as {t_alias}. {e.table_description}" if t_alias else e.table_description
                table_desc_map[e.table_name] = table_desc

                for col_name, col_data in e.column_descriptions.items():
                    
                    
                   
                    if hasattr(col_data, 'alias') and hasattr(col_data, 'description'):
                        alias = getattr(col_data, 'alias', '')
                        desc = getattr(col_data, 'description', '')
                        full_desc = f"Also known as {alias}. {desc}" if alias else desc
                    else:
                        full_desc = str(col_data) 
                        
                    column_desc_map[f"{e.table_name}.{col_name}"] = full_desc
                    
                    

        process_entities(payload.data.tables)
        if hasattr(payload.data, "views") and payload.data.views:
            process_entities(payload.data.views)

        conn = connect_db(payload.data.database_detail)
        with conn.cursor() as cur:
            all_entities = list(table_desc_map.keys())

            for entity_name in all_entities:
                entity_data = next(
                    (e for e in (payload.data.tables + getattr(payload.data, "views", [])) if e.table_name == entity_name),
                    None,
                )
                if not entity_data:
                    continue

                for column in entity_data.column_descriptions.keys():
                    if db_type == "mssql":
                        sql = """
                            SELECT 
                                cols.table_name, cols.column_name, cols.data_type,
                                CASE 
                                    WHEN tc.constraint_type = 'PRIMARY KEY' THEN 'Primary Key'
                                    WHEN tc.constraint_type = 'FOREIGN KEY' THEN 'Foreign Key'
                                    ELSE 'None'
                                END AS constraint_type,
                                fkccu.table_name AS foreign_table,
                                fkccu.column_name AS foreign_column
                            FROM information_schema.columns AS cols
                            LEFT JOIN (
                                SELECT kcu.table_name, kcu.column_name, tc.constraint_type
                                FROM information_schema.table_constraints AS tc
                                JOIN information_schema.key_column_usage AS kcu
                                ON tc.constraint_name = kcu.constraint_name
                                WHERE tc.constraint_type IN ('PRIMARY KEY', 'FOREIGN KEY')
                            ) AS tc ON cols.table_name = tc.table_name AND cols.column_name = tc.column_name
                            LEFT JOIN (
                                SELECT ccu.table_name, ccu.column_name, kcu.table_name AS fk_table, kcu.column_name AS fk_column
                                FROM information_schema.constraint_column_usage AS ccu
                                JOIN information_schema.key_column_usage AS kcu
                                ON ccu.constraint_name = kcu.constraint_name
                            ) AS fkccu ON cols.table_name = fkccu.fk_table AND cols.column_name = fkccu.fk_column
                            WHERE cols.table_name = ? AND cols.column_name = ?
                        """
                        params = (entity_name, column)

                    else:
                        sql = """
                            SELECT 
                                cols.table_name, 
                                cols.column_name, 
                                cols.data_type,
                                COALESCE(tc.constraint_type, 'None') AS constraint_type,
                                ccu.table_name AS foreign_table,
                                ccu.column_name AS foreign_column
                            FROM information_schema.columns cols
                            LEFT JOIN information_schema.key_column_usage kcu
                                ON cols.table_name = kcu.table_name AND cols.column_name = kcu.column_name
                            LEFT JOIN information_schema.table_constraints tc
                                ON kcu.constraint_name = tc.constraint_name AND tc.constraint_type IN ('PRIMARY KEY', 'FOREIGN KEY')
                            LEFT JOIN information_schema.constraint_column_usage ccu
                                ON tc.constraint_name = ccu.constraint_name
                            WHERE cols.table_schema = 'public' AND cols.table_name = %s AND cols.column_name = %s
                        """
                        params = (entity_name, column)

                    cur.execute(sql, params)
                    rows = cur.fetchall()

                    if not rows:
                        continue

                    for row in rows:
                        try:
                            table, col, dtype, constraint, foreign_table, foreign_column = row
                        except Exception:
                            continue

                        if col.lower() == "odataetag":
                            continue

                        t_desc = table_desc_map.get(table, "")
                        c_desc = column_desc_map.get(f"{table}.{col}", "")

                        if constraint.lower() == "foreign key" and foreign_table and foreign_column:
                            rel_str = f"{table.lower()} ({col.lower()}) -> {foreign_table.lower()} ({foreign_column.lower()}): FOREIGN KEY"
                            relationship_lines.append(rel_str)

                        sample_text = "No sample values"
                        if include_sample_values:
                            try:
                                if db_type == "postgres":
                                    sample_query = f'SELECT DISTINCT "{col}" FROM "{table}" WHERE "{col}" IS NOT NULL LIMIT {sample_value_limit}'
                                    cur.execute(sample_query)
                                else:
                                    sample_query = f"SELECT DISTINCT TOP {sample_value_limit} [{col}] FROM [{table}] WHERE [{col}] IS NOT NULL"
                                    cur.execute(sample_query)
                                sample_values = [normalize(r[0]) for r in cur.fetchall()]
                                sample_text = ", ".join(sample_values)
                            except Exception as e:
                                sample_text = f"Error retrieving sample values: {str(e)}"

                        constraint_str = (
                            f"Foreign Key -> {foreign_table}.{foreign_column}" if constraint.lower() == "foreign key"
                            else ("Primary Key" if constraint.lower() == "primary key" else "None")
                        )

                        meta = f"Table_Name: {table}, Table_Description: {t_desc}, Column_Name: {col} (Data_type: {dtype}, Constraint: {constraint_str}), Column_Description: {c_desc}, Column_Sample_Values: {sample_text}"
                        metadata_lines.append(meta)

        with open(metadata_filename, "w", encoding="utf-8") as f:
            for rel in relationship_lines:
                f.write(rel + "\n")
            for meta in metadata_lines:
                f.write(meta + "\n")

        embedding_texts = relationship_lines + metadata_lines
        embeddings = np.array([embedding_model.encode(text, convert_to_numpy=True).astype(np.float32) for text in embedding_texts])
        index = faiss.IndexFlatL2(embeddings.shape[1])
        index.add(embeddings)
        faiss.write_index(index, str(index_filename))

        time.sleep(5)
        load_db_embeddings_in_ram(db_type, label_name)

        return api_response(
            payload.auth.api_key,
            "success",
            f"Metadata and FAISS index generated using selected tables and views: {db_name}",
            200,
            data={
                "metadata_file": str(metadata_filename),
                "index_file": str(index_filename),
                "total_entities": len(table_desc_map),
                "total_columns": len(metadata_lines),
            },
        )

    except Exception as e:
        return api_response(payload.auth.api_key, "error", str(e), 500, data=None)





# API endpoint to generate embeddings for all tables
@app.post("/api/generate-embeddings-all")
def generate_schema_all(payload: GenerateEmbeddingsPayload):

    try:
        include_sample_values = payload.options.include_sample_values
        sample_value_limit = payload.options.sample_value_limit
        db_name = payload.data.database_detail.database_name.lower().replace(" ", "_").replace("-", "_")
        db_type = payload.data.database_detail.database_type.lower()
        label_name = payload.data.label_name

        base_folder = Path("db_schema_embeddings") / db_type
        base_folder.mkdir(parents=True, exist_ok=True)
        type_folder = base_folder / label_name
        type_folder.mkdir(parents=True, exist_ok=True)

        metadata_filename = type_folder / "db_schema.txt"
        index_filename = type_folder / "db_schema_embedding.index"

        table_desc_map = {}
        column_desc_map = {}
        relationship_lines = []
        metadata_lines = []

        def process_entities(entities):
            for e in entities:
                table_desc_map[e.table_name] = e.table_description
                for col_name, col_info in e.column_descriptions.items():
                    if isinstance(col_info, dict):
                        column_desc_map[(e.table_name, col_name)] = col_info.get("description", "Not available")
                    else:
                        column_desc_map[(e.table_name, col_name)] = col_info or "Not available"

        process_entities(payload.data.tables)
        if hasattr(payload.data, "views") and payload.data.views:
            process_entities(payload.data.views)

        conn = connect_db(payload.data.database_detail)
        with conn.cursor() as cur:
            all_entities = list(table_desc_map.keys())

            for entity_name in all_entities:
                columns_query = """
                    SELECT column_name, data_type
                    FROM information_schema.columns
                    WHERE table_name = %s
                """ if db_type == "postgres" else """
                    SELECT column_name, data_type
                    FROM information_schema.columns
                    WHERE table_name = ?
                """
                cur.execute(columns_query, (entity_name,))
                columns = cur.fetchall()

                for column_name, data_type in columns:
                    if db_type == "mssql":
                        constraint_sql = """
                            SELECT 
                                CASE 
                                    WHEN tc.constraint_type = 'PRIMARY KEY' THEN 'Primary Key'
                                    WHEN tc.constraint_type = 'FOREIGN KEY' THEN 'Foreign Key'
                                    ELSE 'None'
                                END AS constraint_type,
                                fkccu.table_name AS foreign_table,
                                fkccu.column_name AS foreign_column
                            FROM information_schema.columns AS cols
                            LEFT JOIN (
                                SELECT kcu.table_name, kcu.column_name, tc.constraint_type
                                FROM information_schema.table_constraints AS tc
                                JOIN information_schema.key_column_usage AS kcu
                                ON tc.constraint_name = kcu.constraint_name
                                WHERE tc.constraint_type IN ('PRIMARY KEY', 'FOREIGN KEY')
                            ) AS tc ON cols.table_name = tc.table_name AND cols.column_name = tc.column_name
                            LEFT JOIN (
                                SELECT ccu.table_name, ccu.column_name, kcu.table_name AS fk_table, kcu.column_name AS fk_column
                                FROM information_schema.constraint_column_usage AS ccu
                                JOIN information_schema.key_column_usage AS kcu
                                ON ccu.constraint_name = kcu.constraint_name
                            ) AS fkccu ON cols.table_name = fkccu.fk_table AND cols.column_name = fkccu.fk_column
                            WHERE cols.table_name = ? AND cols.column_name = ?
                        """
                        constraint_params = (entity_name, column_name)
                    else:
                        constraint_sql = """
                            SELECT 
                                COALESCE(tc.constraint_type, 'None') AS constraint_type,
                                ccu.table_name AS foreign_table,
                                ccu.column_name AS foreign_column
                            FROM information_schema.columns cols
                            LEFT JOIN information_schema.key_column_usage kcu
                                ON cols.table_name = kcu.table_name AND cols.column_name = kcu.column_name
                            LEFT JOIN information_schema.table_constraints tc
                                ON kcu.constraint_name = tc.constraint_name AND tc.constraint_type IN ('PRIMARY KEY', 'FOREIGN KEY')
                            LEFT JOIN information_schema.constraint_column_usage ccu
                                ON tc.constraint_name = ccu.constraint_name
                            WHERE cols.table_schema = 'public' AND cols.table_name = %s AND cols.column_name = %s
                        """
                        constraint_params = (entity_name, column_name)

                    cur.execute(constraint_sql, constraint_params)
                    row = cur.fetchone()
                    constraint, foreign_table, foreign_column = row if row else ("None", None, None)

                    if column_name.lower() == "odataetag":
                        continue

                    t_desc = table_desc_map.get(entity_name, "")
                    c_desc = column_desc_map.get((entity_name, column_name), "Not available")

                    if constraint.lower() == "foreign key" and foreign_table and foreign_column:
                        relationship_lines.append(
                            f"{entity_name.lower()} ({column_name.lower()}) -> {foreign_table.lower()} ({foreign_column.lower()}): FOREIGN KEY"
                        )

                    sample_text = "No sample values"
                    if include_sample_values:
                        try:
                            if db_type == "postgres":
                                sample_query = f'SELECT DISTINCT "{column_name}" FROM "{entity_name}" WHERE "{column_name}" IS NOT NULL LIMIT {sample_value_limit}'
                            else:
                                sample_query = f"SELECT DISTINCT TOP {sample_value_limit} [{column_name}] FROM [{entity_name}] WHERE [{column_name}] IS NOT NULL"
                            cur.execute(sample_query)
                            sample_values = [normalize(r[0]) for r in cur.fetchall()]
                            sample_text = ", ".join(sample_values)
                        except Exception as e:
                            sample_text = f"Error retrieving sample values: {str(e)}"

                    constraint_str = (
                        f"Foreign Key -> {foreign_table}.{foreign_column}" if constraint.lower() == "foreign key"
                        else ("Primary Key" if constraint.lower() == "primary key" else "None")
                    )

                    meta = (
                        f"Table_Name: {entity_name}, Table_Description: {t_desc}, "
                        f"Column_Name: {column_name} (Data_type: {data_type}, Constraint: {constraint_str}), "
                        f"Column_Description: {c_desc}, Column_Sample_Values: {sample_text}"
                    )
                    metadata_lines.append(meta)

        with open(metadata_filename, "w", encoding="utf-8") as f:
            for rel in relationship_lines:
                f.write(rel + "\n")
            for meta in metadata_lines:
                f.write(meta + "\n")

        embedding_texts = relationship_lines + metadata_lines
        embeddings = np.array([
            embedding_model.encode(text, convert_to_numpy=True).astype(np.float32)
            for text in embedding_texts
        ])
        index = faiss.IndexFlatL2(embeddings.shape[1])
        index.add(embeddings)
        faiss.write_index(index, str(index_filename))

        time.sleep(5)
        load_db_embeddings_in_ram(db_type, label_name)

        return api_response(
            payload.auth.api_key,
            "success",
            f"Metadata and FAISS index generated using all tables and columns in: {db_name}",
            200,
            data={
                "metadata_file": str(metadata_filename),
                "index_file": str(index_filename),
                "total_entities": len(table_desc_map),
                "total_columns": len(metadata_lines),
            },
        )

    except Exception as e:
        return api_response(payload.auth.api_key, "error", str(e), 500, data=None)

    
from logs_view import get_log_path, load_json_file, build_html_from_data
import html as html_lib

# ⬇️ सिर्फ एक HTML रूट: /logs
@app.get("/api/logs", response_class=HTMLResponse)
def logs_dashboard_html() -> HTMLResponse:
    """JSON पढ़ो → HTML डैशबोर्ड बनाओ → HTML दो (सिर्फ इसी रूट पर)।"""
    try:
        data = load_json_file(get_log_path())
        html = build_html_from_data(data)
        return HTMLResponse(content=html, status_code=200)
    except FileNotFoundError as e:
        return HTMLResponse(
            f"""
            <html><body style="font-family:Segoe UI, sans-serif; padding:24px">
              <h2>⚠️ all_logs.json not found</h2>
              <p>{html_lib.escape(str(e))}</p>
              <p>Set <code>LOGS_JSON_PATH</code> env var या <code>logs_view.py</code> के पास <code>all_logs.json</code> रखें।</p>
            </body></html>
            """,
            status_code=500,
        )






# ✅ Updated Authentication model with alias for JSON output.
# Now the field is named "fastapi_key".
class Auth(BaseModel):
    api_key: str = Field(...)

# ✅ Options model for request-level settings (applies to the full request).
class RequestOptions(BaseModel):
    set_any_params: bool
    

# ✅ LLM Model Configuration.
class LLMModelConfig(BaseModel):
    name: str
    platform: str
    api_key: str

# ✅ The inner request data model for business-specific fields.
class RequestData(BaseModel):
    chat_history: List[Dict[str, Any]]
    index_list: List[str]
    curr_user_query: str
    database_detail: Dict[str, Any]
    AIModel: LLMModelConfig
    summary_task_model: Optional[LLMModelConfig] = None
    sql_gen_task_model: Optional[LLMModelConfig] = None
    query_refiner_task_model: Optional[LLMModelConfig] = None  # Not used in context; see below.
    error_correction_task_model: Optional[LLMModelConfig] = None
    unspecialized_task_model: Optional[LLMModelConfig] = None
    error_summary_task_model: Optional[LLMModelConfig] = None

# ✅ Full request envelope model with top-level fields:
#    timestamp, fastapi-auth, options, and data.
class RequestEnvelope(BaseModel):
    auth: Auth = Field(..., alias="auth")
    options: RequestOptions
    data: RequestData

# ✅ Helper function to wrap the query response with extra keys.
def create_success_response(query_response: Dict[str, Any]) -> Dict[str, Any]:
    return {
  
        "status": "success",
        "code": 200,
        "message": "Request successful.",
        "data": query_response
    }

# ✅ Unified error response format (default error code 500).
def create_error_response(message: str, code: int = 500) -> Dict[str, Any]:
    return {

        "status": "error",
        "code": code,
        "message": message,
        "data": None
    }





def format_sse(data: Dict[str, Any]) -> bytes:
    """Formats dict into SSE message bytes."""
    return f"sse: {json.dumps(data)}\n\n".encode("utf-8")


async def event_stream(payload: RequestEnvelope) -> AsyncGenerator[str, None]:

    try:

        # Save top-level values if needed.
        request_fastapi_key = payload.auth.api_key
        request_options = payload.options

        # Set context using the inner "data".
        chat_history_ctx.set(payload.data.chat_history)
        # Set the context
        

        # Print inside the request context
        
  

        


        curr_user_query_ctx.set(payload.data.curr_user_query)
        database_detail_ctx.set(payload.data.database_detail)

        # Set the model context variables.
        main_model_ctx.set(payload.data.AIModel.dict())
        summary_model_ctx.set(
            payload.data.summary_task_model.dict() if payload.data.summary_task_model else main_model_ctx.get()
        )
        sql_gen_model_ctx.set(
            payload.data.sql_gen_task_model.dict() if payload.data.sql_gen_task_model else main_model_ctx.get()
        )
        query_refiner_model_ctx.set(
            payload.data.query_refiner_task_model.dict() if payload.data.query_refiner_task_model else main_model_ctx.get()
        )
        error_correction_model_ctx.set(
            payload.data.error_correction_task_model.dict() if payload.data.error_correction_task_model else main_model_ctx.get()
        )
        unspecialized_model_ctx.set(
            payload.data.unspecialized_task_model.dict() if payload.data.unspecialized_task_model else main_model_ctx.get()
        )
        error_summary_model_ctx.set(
            payload.data.error_summary_task_model.dict() if payload.data.error_summary_task_model else main_model_ctx.get()
        )

        # 3. DB Type Check
        db_type = database_detail_ctx.get().get("database_type")
        if db_type not in ["postgres", "mssql"]:
            error_resp = create_error_response(
                fastapi_key=request_fastapi_key,
                message="Invalid database type. Supported types are 'postgres' and 'mssql'.",
                code=400
            )
            yield format_sse(error_resp)
            # REMOVED explicit close yield
            return # Stop generator


        
        try:
            if db_type == "mssql": connect_mssql()
            elif db_type == "postgres": connect_postgres()
        except Exception as e:
            error_resp = create_error_response(
                fastapi_key=request_fastapi_key,
                message=f"Failed to connect to {db_type} database: {str(e)}",
                code=500
            )
            yield format_sse(error_resp)
            # REMOVED explicit close yield
            return # Stop generator

    
        
        try:
            is_connected = test_llm_connection(
                main_model_ctx.get().get("api_key"),
                main_model_ctx.get().get("name"),
                main_model_ctx.get().get("platform")
            )
            if not is_connected: raise ConnectionError("LLM connection test failed.")
        except Exception as e:
             error_resp = create_error_response(
                fastapi_key=request_fastapi_key,
                message=f"Failed to connect to the specified AI Model: {str(e)}",
                code=500
            )
             yield format_sse(error_resp)
             # REMOVED explicit close yield
             return # Stop generator


        # Process the query (this sets query_response_ctx internally).
        async for processed_chunk in process_query_chunk_response(payload.data.curr_user_query):
            if processed_chunk is None:
                return
            yield format_sse(processed_chunk)
            

  
        # success_resp = create_success_response(query_response_ctx.get(), request_fastapi_key)

        # yield format_sse(success_resp)
        # REMOVED explicit close yield
        return # Stop generator after sending final success data

    except asyncio.CancelledError:
        print("SSE connection closed by client.")
        raise # Allow FastAPI/Starlette to handle cleanup
    except Exception as e:
        
        error_resp = create_error_response(
            
            message=f"Unexpected server error during setup: {str(e)}",
            code=500
        )

        yield format_sse(error_resp) # Yield final error

        # REMOVED explicit close yield
        return # Stop generator after attempting to yield error

# The endpoint definition remains unchanged:
@app.post("/api/ask-query-chunk-response")
async def ask_query_chunk_response(payload: RequestEnvelope):
    return StreamingResponse(event_stream(payload), media_type="text/event-stream")







# # ✅ POST /api/ask-query endpoint.
# @app.post("/api/ask-query-chunk-response")
# async def ask_query_chunk_response(payload: RequestEnvelope):
#     try:

#         if payload.auth.api_key not in auth_keys["all_keys"]:
#             return create_error_response(
                
#                 message="Invalid Auth API key.",
#                 code=401
#             )   

#         # Save top-level values if needed.
#         request_fastapi_key = payload.auth.api_key
#         request_options = payload.options

#         # Set context using the inner "data".
#         chat_history_ctx.set(payload.data.chat_history)
#         curr_user_query_ctx.set(payload.data.curr_user_query)
#         database_detail_ctx.set(payload.data.database_detail)

#         # Set the model context variables.
#         main_model_ctx.set(payload.data.AIModel.dict())
#         summary_model_ctx.set(
#             payload.data.summary_task_model.dict() if payload.data.summary_task_model else main_model_ctx.get()
#         )
#         sql_gen_model_ctx.set(
#             payload.data.sql_gen_task_model.dict() if payload.data.sql_gen_task_model else main_model_ctx.get()
#         )
#         query_refiner_model_ctx.set(
#             payload.data.query_refiner_task_model.dict() if payload.data.query_refiner_task_model else main_model_ctx.get()
#         )
#         error_correction_model_ctx.set(
#             payload.data.error_correction_task_model.dict() if payload.data.error_correction_task_model else main_model_ctx.get()
#         )
#         unspecialized_model_ctx.set(
#             payload.data.unspecialized_task_model.dict() if payload.data.unspecialized_task_model else main_model_ctx.get()
#         )
#         error_summary_model_ctx.set(
#             payload.data.error_summary_task_model.dict() if payload.data.error_summary_task_model else main_model_ctx.get()
#         )

#         # check database payload is correct or not.
#         if database_detail_ctx.get().get("database_type") not in ["postgres", "mssql"]: 
#             return create_error_response(
                
#                 message="Invalid database type. Supported types are 'postgres' and 'mssql'.",
#                 code=400
#             )
#         if database_detail_ctx.get().get("database_type") == "mssql":
#             try:
#                 # Connect to MSSQL database
#                 connect_mssql()
#             except Exception as e:
#                 return create_error_response(
                    
#                     message=f"Failed to connect to MSSQL database: {str(e)}",
#                     code=500
#                 )
                
#         elif database_detail_ctx.get().get("database_type") == "postgres":
#             try:
#                 # Connect to PostgreSQL database
#                 connect_postgres()
#             except Exception as e:
#                 return create_error_response(
                    
#                     message=f"Failed to connect to PostgreSQL database: {str(e)}",
#                     code=500
#                 )




#         # check AIModel payload is correct or not.
        
#         # Run the connection check for the provided model and platform
#         is_connected = test_llm_connection(main_model_ctx.get().get("api_key"), 
#                                            main_model_ctx.get().get("name"), 
#                                            main_model_ctx.get().get("platform"))


#         if is_connected:
#             pass
#         else:
#             return create_error_response(
                
#                 message="Failed to connect to the specified AI Model. Please check your API key, model name and AI platform",
#                 code=500
#             )



#         # Process the query (this sets query_response_ctx internally).
#         process_query(payload.data.curr_user_query)

#         if fastapi_response_ctx.get().get("any_error") == "yes":
#             return create_error_response(
            
#             message= fastapi_response_ctx.get().get("error_message"),
#             code= fastapi_response_ctx.get().get("http_status_code")
#         )
            
#         # Wrap and return the query response.
#         return create_success_response(query_response_ctx.get())

#     except Exception as e:
#         return create_error_response(
            
#             message=str(e),
#             code=500
#         )





# ✅ POST /api/ask-query endpoint.
@app.post("/api/ask-query")
async def ask_query(payload: RequestEnvelope):
    log_retrieved_payload(payload.model_dump())


    try:

        if payload.auth.api_key not in auth_keys["all_keys"]:
            return create_error_response(
                
                message="Invalid Auth API key.",
                code=401
            )   

        # Save top-level values if needed.
        request_fastapi_key = payload.auth.api_key
        request_options = payload.options

        # Set context using the inner "data".
        chat_history_ctx.set(payload.data.chat_history)
        index_list_ctx.set(payload.data.index_list)
        curr_user_query_ctx.set(payload.data.curr_user_query)
        database_detail_ctx.set(payload.data.database_detail)

        # Set the model context variables.
        main_model_ctx.set(payload.data.AIModel.dict())
        summary_model_ctx.set(
            payload.data.summary_task_model.dict() if payload.data.summary_task_model else main_model_ctx.get()
        )
        sql_gen_model_ctx.set(
            payload.data.sql_gen_task_model.dict() if payload.data.sql_gen_task_model else main_model_ctx.get()
        )
        query_refiner_model_ctx.set(
            payload.data.query_refiner_task_model.dict() if payload.data.query_refiner_task_model else main_model_ctx.get()
        )
        error_correction_model_ctx.set(
            payload.data.error_correction_task_model.dict() if payload.data.error_correction_task_model else main_model_ctx.get()
        )
        unspecialized_model_ctx.set(
            payload.data.unspecialized_task_model.dict() if payload.data.unspecialized_task_model else main_model_ctx.get()
        )
        error_summary_model_ctx.set(
            payload.data.error_summary_task_model.dict() if payload.data.error_summary_task_model else main_model_ctx.get()
        )

        # check database payload is correct or not.
        if database_detail_ctx.get().get("database_type") not in ["postgres", "mssql"]: 
            return create_error_response(
                
                message="Invalid database type. Supported types are 'postgres' and 'mssql'.",
                code=400
            )

        if database_detail_ctx.get().get("database_type") == "mssql":
            try:
                # Connect to MSSQL database
                conn = await connect_mssql()
                await conn.close()
            except Exception as e:
                return create_error_response(
                    
                    message=f"{str(e)}",
                    code=500
                )
                
        elif database_detail_ctx.get().get("database_type") == "postgres":
            try:
                # Connect to PostgreSQL database
                conn = await connect_postgres()
                await conn.close()
            except Exception as e:
                return create_error_response(
                    
                    message=f"{str(e)}",
                    code=500
                )




        # check AIModel payload is correct or not.
        
        # Run the connection check for the provided model and platform
        is_connected = test_llm_connection(main_model_ctx.get().get("api_key"), 
                                           main_model_ctx.get().get("name"), 
                                           main_model_ctx.get().get("platform"))


        if is_connected:
            pass
        else:
            return create_error_response(
                
                message="Failed to connect to the specified AI Model. Please check your API key, model name and AI platform",
                code=500
            )



        # Process the query (this sets query_response_ctx internally).
        await process_query(payload.data.curr_user_query)

        # print("query_response_ctx of try:\n", query_response_ctx.get())

        if fastapi_response_ctx.get().get("any_error") == "yes":
            return create_error_response(
            
            message= fastapi_response_ctx.get().get("error_message"),
            code= fastapi_response_ctx.get().get("http_status_code")
        )
            
        # Wrap and return the query response.
        #return create_success_response(query_response_ctx.get())
        final_response = create_success_response(query_response_ctx.get())
        #print("📤 Full Response:\n", json.dumps(final_response, indent=2, ensure_ascii=False))
        log_retrieved_response(final_response)
        #print("📤 Full Response:\n", json.dumps(final_response, indent=2, ensure_ascii=False))
        return final_response

    except Exception as e:
        # print("query_response_ctx of except:\n", query_response_ctx.get())
        return create_error_response(
            
            message=str(e),
            code=500
        )

# ✅ POST /api/summery-prompt endpoint.
class SummaryPromptData(BaseModel):
    prompt: str

class SummaryPromptRequest(BaseModel):
    auth: Auth
    data: SummaryPromptData

@app.post("/api/summery-prompt")
def update_summary_prompt(payload: SummaryPromptRequest):
    try:
        # Validate API Key
        if payload.auth.api_key not in auth_keys["all_keys"]:
            return create_error_response(
                message="Invalid Auth API key.",
                code=401
            )
            
        prompt_content = payload.data.prompt
        
        # Save to file in the same directory as app.py
        current_dir = Path(__file__).resolve().parent
        prompt_file_path = current_dir / "summary_prompt_style.txt"
        
        with open(prompt_file_path, "w", encoding="utf-8") as f:
            f.write(prompt_content)
            
        return api_response(
            payload.auth.api_key,
            "success",
            "Summary prompt style updated successfully.",
            200,
            data={"saved_prompt_length": len(prompt_content)}
        )
    except Exception as e:
        return create_error_response(
            message=str(e),
            code=500
        )


# ----------------------------------------------------------------
# 📝 System Prompt Management (Dynamic Prompts)
# ----------------------------------------------------------------
from summary_utils import STATIC_SYSTEM_PROMPT, DEFAULT_DYNAMIC_PART

# Ensure this matches where summary_utils.py looks!
PROMPT_FILE_PATH = Path("Output_prompt/system_prompts.json")

class PromptUpdateRequest(BaseModel):
    STATIC_SYSTEM_PROMPT: Optional[str] = None
    DEFAULT_DYNAMIC_PART: Optional[str] = None

class PromptUpdatePayload(BaseModel):
    auth: Auth
    data: Optional[PromptUpdateRequest] = None

@app.get("/api/prompts")
def get_prompts():
    if not PROMPT_FILE_PATH.exists():
        return {
            "message": "system_prompts.json not found"
        }

    return json.loads(
        PROMPT_FILE_PATH.read_text(encoding="utf-8")
    )

# @app.post("/api/prompts")
# def update_prompts(payload: PromptUpdatePayload):
#     # Case 1: If data is missing or empty fields -> RESET defaults
#     if not payload.data or not payload.data.dict(exclude_none=True):
#         data = {
#             "STATIC_SYSTEM_PROMPT": STATIC_SYSTEM_PROMPT,
#             "DEFAULT_DYNAMIC_PART": DEFAULT_DYNAMIC_PART,
#         }

#         PROMPT_FILE_PATH.write_text(
#             json.dumps(data, indent=2, ensure_ascii=False),
#             encoding="utf-8"
#         )

#         return {
#             "message": "Prompts reset to defaults from summary_utils.py",
#             "source": "defaults",
#             "file": str(PROMPT_FILE_PATH)
#         }
    
#     # Case 2: Update provided fields
#     data = {
#         "STATIC_SYSTEM_PROMPT": STATIC_SYSTEM_PROMPT,
#         "DEFAULT_DYNAMIC_PART": DEFAULT_DYNAMIC_PART,
#     }

#     if PROMPT_FILE_PATH.exists():
#         try:
#             existing = json.loads(PROMPT_FILE_PATH.read_text(encoding="utf-8"))
#             data.update(existing)
#         except Exception:
#             pass  

#     updates = payload.data
#     if updates.STATIC_SYSTEM_PROMPT:
#         data["STATIC_SYSTEM_PROMPT"] = updates.STATIC_SYSTEM_PROMPT.strip()

#     if updates.DEFAULT_DYNAMIC_PART:
#         data["DEFAULT_DYNAMIC_PART"] = updates.DEFAULT_DYNAMIC_PART.strip()

#     PROMPT_FILE_PATH.write_text(
#         json.dumps(data, indent=2, ensure_ascii=False),
#         encoding="utf-8"
#     )

#     return {
#         "message": "Prompts updated successfully",
#         "source": "client + defaults",
#         "file": str(PROMPT_FILE_PATH)
#     }


@app.post("/api/prompts")
def update_prompts(payload: PromptUpdatePayload):
    updates = payload.data.dict(exclude_none=True) if payload.data else {}

    # 🚫 Case 1: Empty payload → ERROR (no silent override)
    if not updates:
        return {
            "error": "No prompt fields provided. Nothing to update."
        }

    # # 🟢 Case 2: File does NOT exist → initialize with defaults
    # if not PROMPT_FILE_PATH.exists():
    #     data = {
    #         "STATIC_SYSTEM_PROMPT": STATIC_SYSTEM_PROMPT,
    #         "DEFAULT_DYNAMIC_PART": DEFAULT_DYNAMIC_PART,
    #     }
    # else:
    #     # 🟡 Case 3: File exists → load existing (KEEP AS-IS)
    #     try:
    #         data = json.loads(PROMPT_FILE_PATH.read_text(encoding="utf-8"))

    #     except Exception:
    #         return {
    #             "error": "system_prompts.json is corrupted. Fix or reset manually."
    #         }
    if  PROMPT_FILE_PATH.exists():
        try:
            data = json.loads(PROMPT_FILE_PATH.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                return {
                    "error": "system_prompts.json has invalid structure."
                }
        except Exception:
            return {
                "error": "system_prompts.json is corrupted. Fix or reset manually."
            }
    else:
        data = {} # ← IMPORTANT: start EMPTY, not defaults

    # 🟢 Override ONLY what client explicitly sends
    if "STATIC_SYSTEM_PROMPT" in updates:
        value = updates["STATIC_SYSTEM_PROMPT"].strip()
        if not value:
            return {
                "error": "STATIC_SYSTEM_PROMPT cannot be empty"
            }
        data["STATIC_SYSTEM_PROMPT"] = value

    if "DEFAULT_DYNAMIC_PART" in updates:
        value = updates["DEFAULT_DYNAMIC_PART"].strip()
        if not value:
            return {
                "error": "DEFAULT_DYNAMIC_PART cannot be empty"
            }
        data["DEFAULT_DYNAMIC_PART"] = value

    # ✍️ Write back safely
    PROMPT_FILE_PATH.write_text(
        json.dumps(data, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

    return {
        "message": "Prompts updated successfully",
        "updated_fields": list(updates.keys()),
        "file": str(PROMPT_FILE_PATH)
    }
