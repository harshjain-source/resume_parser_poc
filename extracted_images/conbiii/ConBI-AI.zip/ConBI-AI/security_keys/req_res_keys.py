auth_keys = {
    "all_keys": ["prateek@1234", "prateek@123", "deepaksir@123", "premsir@123", "xyz789"]
}