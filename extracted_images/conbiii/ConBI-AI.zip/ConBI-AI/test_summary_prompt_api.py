import requests
import json

# Configuration
API_URL = "http://127.0.0.1:8000/api/summery-prompt"
API_KEY = "prateek@1234"  # Using one of the valid keys form security_keys/req_res_keys.py

# New style prompt content you want to set
new_prompt_style = """
--------------------------------
1. SUMMARY (HTML) – "Visual & Engaging" (UPDATED STYLE)
--------------------------------
In "summary":
- **Headline**: Start with a single <h3> sentence that answers the core question immediately.
- **The "Story"**: Write 1-2 short paragraphs explaining *why* the numbers look this way.
- **Tone**: Professional yet conversational.
- **Formatting**:
  - Use <b> for key metrics.
  - Use <i> for subtle context.
  - **Emojis**: Use emojis sparingly but effectively (e.g., 🚀 for growth).

--------------------------------
2. KEY INSIGHTS BLOCK
--------------------------------
<h3>💡 Key Strategic Insights</h3>
<ul>
  <li>🟢 <b>Positive</b>: Growth areas.</li>
  <li>🔴 <b>Risk</b>: Areas of concern.</li>
</ul>

--------------------------------
FINAL OUTPUT FORMAT – STRICT JSON
--------------------------------
Return ONLY a valid JSON object.
{
  "summary": "...",
  "chart_details": [...],
  "suggested_followups": [...]
}
"""

def update_prompt():
    payload = {
        "auth": {
            "api_key": API_KEY
        },
        "data": {
            "prompt": new_prompt_style
        }
    }

    try:
        print(f"Sending request to {API_URL}...")
        response = requests.post(API_URL, json=payload)
        
        print(f"Status Code: {response.status_code}")
        try:
            print("Response JSON:", json.dumps(response.json(), indent=2))
        except:
            print("Response Text:", response.text)

    except requests.exceptions.ConnectionError:
        print("❌ Could not connect to the server. Make sure the FastAPI app is running on port 8000.")
        print("Run: uvicorn app:app --reload")

if __name__ == "__main__":
    update_prompt()
