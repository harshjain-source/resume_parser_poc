import os
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

# Load the embedding model (same one used for generating embeddings)
embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

# Function to retrieve top-k similar results based on input query and threshold similarity
def retrieve_embeddings(input_text, db_type, db_name, top_k=10, threshold_similarity=0.75):
    try:
        # Use the same logic as the original code to handle db_name and db_type
        db_name = db_name.lower().replace(" ", "_").replace("-", "_")
        db_type = db_type.lower()

        # Set up the folder path for the index and db_schema files using os module
        base_folder = os.path.join("db_schema_embeddings", db_type)
        db_folder = os.path.join(base_folder, db_name)
        index_filename = os.path.join(db_folder, "db_schema_embedding.index")
        db_schema_filename = os.path.join(db_folder, "db_schema.txt")
        
        # Check if the files exist
        if not os.path.exists(index_filename) or not os.path.exists(db_schema_filename):
            print("Error: Index or db_schema file not found for the given database.")
            return []

        # Load the FAISS index
        index = faiss.read_index(index_filename)
        
        # Embed the input query to get the query vector
        query_embedding = embedding_model.encode(input_text, convert_to_numpy=True).astype(np.float32)

        # Perform the search on the FAISS index
        D, I = index.search(np.array([query_embedding]), top_k)

        # Read the db_schema from the file
        with open(db_schema_filename, "r", encoding="utf-8") as f:
            db_schema_lines = f.readlines()

        # Store the input and retrieved entries with similarity scores in a data structure (list of dictionaries)
        document_retrieved = {
            "input_text": input_text,
            "retrieved_entries": []
        }

        for i, idx in enumerate(I[0]):
            # Get the distance (similarity score) and check if it is above the threshold
            similarity_score = D[0][i]
            if similarity_score >= threshold_similarity:
                # Add the retrieved entry to the structure
                document_retrieved["retrieved_entries"].append({
                    "db_schema": db_schema_lines[idx].strip(),
                    "similarity_score": similarity_score
                })

        # Call the function to sort and extract only the sorted db_schema
        sorted_db_schema = extract_sorted_db_schema(document_retrieved)

        # Return the sorted db_schema
        return sorted_db_schema

    except Exception as e:
        print(f"Error: {str(e)}")
        return []

# Function to sort and return only the sorted db_schema (line by line)
def extract_sorted_db_schema(document_retrieved):
    # Extract the retrieved entries
    retrieved_entries = document_retrieved.get("retrieved_entries", [])

    # Sort the retrieved entries alphabetically based on table and column name
    retrieved_entries.sort(key=lambda x: (x['db_schema'].split(",")[0], x['db_schema'].split(",")[1]))

    # Extract the sorted db_schema and return it as a multi-line string
    sorted_db_schema = "\n".join([entry['db_schema'] for entry in retrieved_entries])

    return sorted_db_schema

# Testing the function
if __name__ == "__main__":
    input_text = "total project of bihar"
    db_type = "mssql"  # Database type (could be mssql or postgres)
    db_name = "rodic_bi"  # Name of the database
    top_k = 10  # Number of top similar results to return
    threshold_similarity = 0.10  # Minimum similarity score to consider a result

    # Retrieve the input and retrieved entries in a structured format
    sorted_db_schema = retrieve_embeddings(input_text, db_type, db_name, top_k, threshold_similarity)

    # Writing sorted metadata to a text file (just for illustration)
    with open("sorted_db_schema.txt", "w", encoding="utf-8") as f:
        f.write(sorted_db_schema)

    # Print the sorted db_schema, each entry in a new line
    print("\nSimplified Results (db_schema only, sorted alphabetically):")
    if sorted_db_schema:
        print(sorted_db_schema)  # All results will be printed line by line
    else:
        print("No results found.")




