#====================================================================Experiment code

# ----------------------------------------
# 📁 main.py (Production-grade NL2SQL processor using ContextVars)
# ----------------------------------------

import re
from typing import List, Dict, Any
import asyncio
import copy
import json
from typing import Dict, Any, List, AsyncGenerator

from context import (
    chat_history_ctx, curr_user_query_ctx, database_detail_ctx, set_chart_details, index_list_ctx,
    retrieved_db_schema_for_query_ctx, query_response_ctx, error_sql_attempts_ctx,
    set_original_query_in_response, set_total_refined_query_in_response, set_refined_query_list_in_response,
    add_sql_result_in_response, set_summary_in_response, log_failed_sql_attempt, fastapi_response_ctx,
    set_suggested_followups_in_response,  # ✅ ADDED: import setter for follow-ups
)
from sql_output_parser import extract_generated_sql
from query_refiner_utils import build_refiner_prompt, build_key_prompt
from sql_gen_utils import build_sql_generation_prompt
from sql_error_utils import build_error_correction_prompt, extract_corrected_sql
from summarize_error import summarize_error_if_needed
from summary_utils import build_summary_prompt
from database import execute_mssql_query, execute_postgres_query
from llm import call_llm
from retrieve_db_schema import get_relevant_db_schema_for_query, get_business_db_schema_for_query
from elastic_search import handle_all_searches
from logger_utils import log_final_prompt

# ✅ Format SQL results as list of dicts
# def format_sql_result(columns, rows) -> List[Dict[str, Any]]:
#     return [dict(zip(columns, row)) for row in rows]
def format_sql_result(columns: List[str], rows: List[tuple]) -> List[Dict[str, Any]]:
    formatted = []
    for row in rows:
        row_dict = {}
        for col, val in zip(columns, row):
            if isinstance(val, Decimal):
                val = str(val)  # preserve precision, avoid JSON issues
            elif isinstance(val, (datetime, date)):
                val = val.isoformat()  # convert to string for JSON serialization
            row_dict[col] = val
        formatted.append(row_dict)
    return formatted


# ✅ Helper function to wrap the query response with extra keys.
def create_success_response(query_response: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "status": "success",
        "code": 200,
        "message": "Request successful.",
        "data": query_response
    }

# ✅ Unified error response format (default error code 500).
def create_error_response(message: str, code: int = 500) -> Dict[str, Any]:
    return {
        "status": "error",
        "code": code,
        "message": message,
        "data": None
    }


error_prefix_to_check = "cannot generate sql"


async def process_query_chunk_response(raw_query: str) -> AsyncGenerator[Dict[str, Any], None]:
    db_type = database_detail_ctx.get().get("database_type")

    # Step 1: Save original query and get DB schema
    set_original_query_in_response(raw_query)
    try:
        get_relevant_db_schema_for_query(raw_query, 30, 0.0)  # query, top_k, simillarity_threshold
    except:
        yield create_error_response("Error in getting relevant DB schema of original query({raw_query}) for query refinement, calling from main.py file")
        return

    # Step 2: Refine query using LLM test
    messages = build_refiner_prompt()
    try:
        refinement_response = call_llm("query_refiner", messages)
    except:
        yield create_error_response("Error in calling LLM for query refinement from main.py file")
        return

    count, refined_queries = parse_refined_response(refinement_response)
    set_total_refined_query_in_response(count)
    set_refined_query_list_in_response(refined_queries)

    # Step 3: Process each refined query
    for query in query_response_ctx.get()["refined_query_list"]:

        yield create_success_response({"refined_query": query})

        try:
            get_relevant_db_schema_for_query(query, 30, 0.0)
        except:
            yield create_error_response(f"Error in getting relevant DB schema of refined query({query}) for SQL generation, calling from main.py file")
            return
        schema_str = retrieved_db_schema_for_query_ctx.get()  # extracted schema will be
                                                              # different for each query keep in mind

        success = False
        final_result_str = None
        final_sql_used = None
        final_remarks = ""

        #  Generate SQL
        try:
            gen_prompt = build_sql_generation_prompt(query, schema_str)
            gen_response = call_llm("sql_gen", gen_prompt)
            parsed = extract_generated_sql(gen_response)
            sql_query = parsed.final_sql
        except Exception as e:
            yield create_success_response({"generated_sql": f"{gen_response}",
                                           "executed_sql_output": {"error_message": f"Not executed because sql query was not generated or extracted properly error is: {str(e)}"}})
            continue

        try:
            if database_detail_ctx.get().get("database_type") == "postgres":
                final_result_str = execute_postgres_query(sql_query)
            elif database_detail_ctx.get().get("database_type") == "mssql":
                final_result_str = execute_mssql_query(sql_query)

            yield create_success_response({"generated_sql": f"{sql_query}",
                                           "executed_sql_output": f"{final_result_str}"})
            final_sql_used = sql_query
            final_remarks = ""
            success = True

        except Exception as e:
            summarized_error = summarize_error_if_needed(str(e))
            log_failed_sql_attempt(1, query, sql_query, summarized_error)

            MAX_ERROR_ATTEMPTS = 3

            for attempt in range(1, MAX_ERROR_ATTEMPTS + 1):
                try:
                    correction_prompt = build_error_correction_prompt(query, schema_str, error_sql_attempts_ctx.get())
                    correction_response = call_llm("error_correction", correction_prompt)
                    parsed_corrected = extract_corrected_sql(correction_response)
                    sql_query = parsed_corrected.final_sql
                except Exception as e:
                    yield create_success_response({"generated_sql": f"{correction_response}",
                                                   "executed_sql_output": {"error_message": f"Not executed because sql query was not generated or extracted properly error is: {str(e)}"}})
                    final_result_str = [{f"message": f"Something went wrong in error correction part of query, error is : {str(e)}"}]
                    final_sql_used = sql_query
                    final_remarks = ""
                    break
                try:

                    if database_detail_ctx.get().get("database_type") == "postgres":
                        final_result_str = execute_postgres_query(sql_query)
                    elif database_detail_ctx.get().get("database_type") == "mssql":
                        final_result_str = execute_mssql_query(sql_query)

                    yield create_success_response({"generated_sql": f"{sql_query}",
                                                   "executed_sql_output": f"{final_result_str}"})

                    final_sql_used = sql_query
                    final_remarks = f"✅ Success on  attempt {attempt} after getting error"
                    success = True
                    break
                except Exception as e:
                    summarized_error = summarize_error_if_needed(str(e))
                    log_failed_sql_attempt(attempt, query, sql_query, summarized_error)

                    if attempt == MAX_ERROR_ATTEMPTS:
                        yield create_success_response({"generated_sql": f"{sql_query}",
                                                       "executed_sql_output": {"error_message": f"could not solve after 3 attempts error is: {str(e)}"}})

                        final_result_str = [{f"message": f"Could not solve this query even though attempting 3 times to solve and error is: {str(e)}"}]
                        final_sql_used = sql_query
                        final_remarks = ""

        add_sql_result_in_response(query, final_sql_used, final_result_str, final_remarks)
        error_sql_attempts_ctx.set({})  # Clear context after each query

    # Step 4: Generate and store summary
    summary_prompt = build_summary_prompt(query_response_ctx.get())
    summary_response = call_llm("summary", summary_prompt)

    # ✅ NEW: Try to parse JSON to fetch follow-ups (graceful fallback if not JSON)
    try:
        parsed_summary = json.loads(summary_response)
        # Keep original behavior for summary text if available
        set_summary_in_response(parsed_summary.get("summary", summary_response))
        # Optional: set chart_details if provided (no change to logic if absent)
        if "chart_details" in parsed_summary:
            set_chart_details(parsed_summary.get("chart_details", []))
        # ✅ Set suggested followups if provided
        set_suggested_followups_in_response(parsed_summary.get("suggested_followups", []))
        yield create_success_response({"summary": parsed_summary.get("summary", "")})
    except Exception:
        # Fallback to your original behavior if response isn't JSON
        set_summary_in_response(summary_response)
        yield create_success_response({"summary": f"{summary_response}"})
    return


# ✅ Main entrypoint
async def process_query(raw_query: str) -> str:

    db_type = database_detail_ctx.get().get("database_type")

    any_sub_query_run = False

    error_prefix_to_check = "cannot generate sql"

    # Step 1: Save original query and get DB schema
    set_original_query_in_response(raw_query)
    try:
        get_relevant_db_schema_for_query(raw_query, 25, 1.9)  # query, top_k, simillarity_threshold
    except Exception as e:
        fastapi_response_ctx.set({
            "any_error": "yes",
            "http_status_code": 500,
            "error_message": f"Error in getting relevant DB schema of original query({raw_query}) for query refinement. Error is: {str(e)}"
        })
        return

    try:
        print("try 1")
        message = build_key_prompt(raw_query)
        import json
        print("try 2")
        # Call LLM (यहाँ आपका call_llm function यूज़ करें)
        key_point_str = await call_llm("summary", message)

        print("try 3")
        print("LLM Response:", key_point_str)

        # 3. Extract JSON substring
        match = re.search(r"\{.*\}", key_point_str, re.DOTALL)
        if match:
            json_str = match.group(0)
            try:
                key_point = json.loads(json_str)
            except json.JSONDecodeError:
                print("❌ JSON decoding failed, returning empty dict")
                key_point = {}
        else:
            print("❌ No JSON object found, returning empty dict")
            key_point = {}

        # 4. Get the active index list from context (no hardcoding)
        index_list = index_list_ctx.get([])  # e.g. ["project_name", "project_manager", "organization_name"]
        print("Active index_list:", index_list)

        # 5. Extract dynamically
        extracted_values = {k: key_point.get(k) for k in index_list}

        # 6. Call search handler dynamically
        results = await handle_all_searches(extracted_values)

        print("all data", results)

        messages = build_refiner_prompt(**results)
        refinement_response = await call_llm("query_refiner", messages)

        import json

        try:
            parsed = json.loads(refinement_response)
            count = parsed["count"]
            queries = parsed["queries"]
            print("✅ Count:", count)
            print("✅ Queries:", queries)

            # 👇 Now pass to your functions
            set_total_refined_query_in_response(count)
            set_refined_query_list_in_response(queries)

        except json.JSONDecodeError as e:
            print("❌ JSON Decode Error:", e)
            print("❌ Raw Response:", refinement_response)

    except Exception as e:
        print("exception occured")
        fastapi_response_ctx.set({
            "any_error": "yes",
            "http_status_code": 500,
            "error_message": f"Error in query refinement process. Error is: {str(e)}"
        })
        return

    # Step 3: Process each refined query
    for query in query_response_ctx.get()["refined_query_list"]:

        add_result_in_summary = False
        skip_the_query = False
        try:

            business_str = get_business_db_schema_for_query(query, 10, 1.8)
            print("business_str: ", business_str)

            get_relevant_db_schema_for_query(query, 22, 1.8)
            schema_str = retrieved_db_schema_for_query_ctx.get()
            print("+++++++++++++++++++++++++++++")

        except Exception as e:
            fastapi_response_ctx.set({
                "any_error": "yes",
                "http_status_code": 500,
                "error_message": f"Error in getting relevant DB schema of refined query({query}) for SQL generation. Error is: {str(e)}"
            })
            return

        success = False
        final_result_str = None
        final_sql_used = None
        final_remarks = ""

        sql_query = ""

        print("try 5")
        try:
            for i in range(2):
                print("try 6")
                gen_prompt = build_sql_generation_prompt(query, schema_str, business_str)
                log_final_prompt(gen_prompt)

                print("try 7")

                gen_response = await call_llm("sql_gen", gen_prompt)
                print("13 ✓✓✓", gen_response)
                pattern = r'"final_sql"\s*:\s*""cannot generate sql'
                if re.search(pattern, gen_response, flags=re.IGNORECASE):

                    print("14")
                    if i == 1:
                        print("15")
                        skip_the_query = True
                        fastapi_response_ctx.set({
                            "any_error": "yes",
                            "http_status_code": 500,
                            "error_message": f"Error in generating SQL query for refined query seems due to not having proper table and column: {query}."
                        })

                    continue

                print("16")
                parsed = extract_generated_sql(gen_response)
                print("17")
                sql_query = parsed.final_sql
                break

        except Exception as e:
            print("19")
            fastapi_response_ctx.set({
                "any_error": "yes",
                "http_status_code": 500,
                "error_message": f"Error in generating SQL query for refined query: {query}. \nError is: {str(e)}"
            })
            skip_the_query = True

        if skip_the_query:
            continue
        print("20")
        try:
            print("21")
            if database_detail_ctx.get().get("database_type") == "postgres":
                final_result_str = await execute_postgres_query(sql_query)
            elif database_detail_ctx.get().get("database_type") == "mssql":
                final_result_str = await execute_mssql_query(sql_query)

            final_sql_used = sql_query
            final_remarks = ""
            success = True
            any_sub_query_run = True
            add_result_in_summary = True

        except Exception as e:
            summarized_error = await summarize_error_if_needed(str(e))
            log_failed_sql_attempt(1, query, sql_query, summarized_error)

            MAX_ERROR_ATTEMPTS = 3

            for attempt in range(1, MAX_ERROR_ATTEMPTS + 1):
                try:
                    correction_prompt = build_error_correction_prompt(query, schema_str, error_sql_attempts_ctx.get())
                    correction_response = await call_llm("error_correction", correction_prompt)

                    pattern = r'"final_sql"\s*:\s*""cannot generate sql'
                    if re.search(pattern, correction_response, flags=re.IGNORECASE):

                        fastapi_response_ctx.set({
                            "any_error": "yes",
                            "http_status_code": 500,
                            "error_message": f"Error in generating SQL query(in correction attempt) for refined query: {query}. \nError is: {str(e)}"
                        })

                        break

                    parsed_corrected = extract_corrected_sql(correction_response)
                    sql_query = parsed_corrected.final_sql

                except Exception as e:
                    final_result_str = [{f"message": f"Could not generate sql query in  error correction attempt of query: {query}. \n Error is : {str(e)}"}]
                    final_sql_used = sql_query
                    final_remarks = ""

                try:

                    if database_detail_ctx.get().get("database_type") == "postgres":
                        final_result_str = await execute_postgres_query(sql_query)
                    elif database_detail_ctx.get().get("database_type") == "mssql":
                        final_result_str = await execute_mssql_query(sql_query)

                    final_sql_used = sql_query
                    final_remarks = f"✅ Success on  attempt {attempt} after getting error"
                    success = True
                    any_sub_query_run = True
                    add_result_in_summary = True
                    break
                except Exception as e:
                    summarized_error = await summarize_error_if_needed(str(e))
                    log_failed_sql_attempt(attempt, query, sql_query, summarized_error)

                    if attempt == MAX_ERROR_ATTEMPTS:
                        final_result_str = [{f"message": f"Could not solve this query even though attempting 3 times to solve and error is: {str(e)}"}]
                        final_sql_used = sql_query
                        final_remarks = ""

        if add_result_in_summary:
            add_sql_result_in_response(query, final_sql_used, final_result_str, final_remarks)
        error_sql_attempts_ctx.set({})  # Clear context after each query

    # Step 4: Generate and store summary
    try:
        if any_sub_query_run:
            # Step 2: Create deep copy to avoid mutation
            copy_query_response_ctx = copy.deepcopy(query_response_ctx.get())

            # Step 3: Truncate `executed_sql_output` to max 20 rows per query
            for item in copy_query_response_ctx["query_sql_answer"]:
                item["executed_sql_output"] = item["executed_sql_output"][:10]

            summary_prompt = build_summary_prompt(copy_query_response_ctx)

            # Assuming summary_response is the result from the LLM call
            summary_response = await call_llm("summary", summary_prompt)
            summary_response = json.loads(summary_response)
            # print("full summary", summary_response)

            # Set the summary text
            set_summary_in_response(summary_response['summary'])

            # Extract the full chart_details list
            chart_details = summary_response.get("chart_details", [])
            # Store the full chart_details list in context
            set_chart_details(chart_details)

            # ✅ NEW: Store suggested follow-ups (if present)
            set_suggested_followups_in_response(summary_response.get("suggested_followups", []))

        else:
            fastapi_response_ctx.set({
                "any_error": "yes",
                "http_status_code": 500,
                "error_message": f"Not able to answer"
            })
    except Exception as e:  # Catches errors from call_llm or other summary steps
        fastapi_response_ctx.set({
            "any_error": "yes",
            "http_status_code": 500,
            "error_message": f"Error in generating summary. \nError is: {str(e)}"
        })
