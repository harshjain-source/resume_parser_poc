from contextvars import ContextVar
from typing import Any, Dict, List, Optional

# ======================== Input Data from Request ========================

chat_history_ctx: ContextVar[List[Dict[str, Any]]] = ContextVar("chat_history")
index_list_ctx: ContextVar[List[str]] = ContextVar("index_list")
curr_user_query_ctx: ContextVar[str] = ContextVar("curr_user_query")
database_detail_ctx: ContextVar[Dict[str, Any]] = ContextVar("database_detail")

# ======================== LLM Model Configuration ========================

# These model contexts accept:
# {
#   "name": "gpt-4o",
#   "platform": "openai",
#   "api_key": "sk-..."
# }

main_model_ctx: ContextVar[Dict[str, str]] = ContextVar("main_model")
summary_model_ctx: ContextVar[Dict[str, str]] = ContextVar("summary_model")
sql_gen_model_ctx: ContextVar[Dict[str, str]] = ContextVar("sql_gen_model")
query_refiner_model_ctx: ContextVar[Dict[str, str]] = ContextVar("query_refiner_model")
error_correction_model_ctx: ContextVar[Dict[str, str]] = ContextVar("error_correction_model")
unspecialized_model_ctx: ContextVar[Dict[str, str]] = ContextVar("unspecialized_model")
error_summary_model_ctx: ContextVar[Dict[str, str]] = ContextVar("error_summary_model")

# ======================== DB Schema Context ========================

retrieved_db_schema_for_query_ctx: ContextVar[str] = ContextVar("retrieved_db_schema_for_query")

# ======================== Output Context for Building Final Response ========================

query_response_ctx: ContextVar[Dict[str, Any]] = ContextVar("query_response", default={
    "original_query": "",
    "total_refined_query": 0,
    "refined_query_list": [],
    "query_sql_answer": [],
    "summary": "",
    "suggested_followups": []  # ✅ Added field for suggested questions
})

# ======================== Helper Functions for Updating Query Response ========================

def set_original_query_in_response(text: str):
    data = query_response_ctx.get().copy()
    data["original_query"] = text
    query_response_ctx.set(data)

def set_total_refined_query_in_response(count: int):
    data = query_response_ctx.get().copy()
    data["total_refined_query"] = count
    query_response_ctx.set(data)

def set_refined_query_list_in_response(queries: List[str]):
    data = query_response_ctx.get().copy()
    data["refined_query_list"] = queries
    query_response_ctx.set(data)

def add_sql_result_in_response(refined_query: str, sql: str, output: List[Dict[str, Any]], remarks: str):
    data = query_response_ctx.get().copy()

    if output:
        column_names = list(output[0].keys())
    else:
        column_names = []
    
    print(column_names)

    data["query_sql_answer"].append({
        "refined_query": refined_query,
        "generated_sql": sql,
        "executed_sql_output": output,
        "remarks": remarks,
        "column_names": column_names
    })
    query_response_ctx.set(data)

def set_summary_in_response(text: str):
    data = query_response_ctx.get().copy()
    data["summary"] = text
    query_response_ctx.set(data)

def set_chart_details(chart_details: list):
    data = query_response_ctx.get().copy()
    data["chart_details"] = chart_details
    query_response_ctx.set(data)

# ✅ NEW FUNCTION — Adds suggested follow-ups safely
def set_suggested_followups_in_response(items: List[str]):
    """
    Store 2–3 concise, actionable follow-up questions returned by the AI model.
    Non-invasive: cleans strings, removes duplicates, caps at 3.
    """
    data = query_response_ctx.get().copy()
    
    cleaned: List[str] = []
    for x in items or []:
        if not isinstance(x, str):
            continue
        t = " ".join(x.split()).strip()
        if not t:
            continue
        cleaned.append(t)
    
    # De-dup while keeping order
    seen = set()
    unique = []
    for t in cleaned:
        low = t.lower()
        if low in seen:
            continue
        seen.add(low)
        unique.append(t)
    
    # Cap to 3 follow-ups max
    data["suggested_followups"] = unique[:3]
    query_response_ctx.set(data)

# ======================== SQL Error Attempts Tracker ========================

error_sql_attempts_ctx: ContextVar[Dict[str, Any]] = ContextVar("error_sql_attempts", default={})

def log_failed_sql_attempt(attempt_num: int, query: str, sql: str, error_msg: str):
    data = error_sql_attempts_ctx.get().copy()
    data[f"attempt_{attempt_num}"] = {
        "query": query,
        "generated_sql": sql,
        "executed_sql_output": error_msg,
        "remarks": ""
    }
    error_sql_attempts_ctx.set(data)

#=========================================================================

fastapi_response_ctx: ContextVar[Dict[str, any]] = ContextVar("fastapi_response", default={
    "any_error": "no",
    "http_status_code": 200,
    "error_message": ""
})
