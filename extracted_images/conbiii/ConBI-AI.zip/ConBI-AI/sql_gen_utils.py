# ----------------------------------------
# 📁 sql_gen_utils.py (Dynamic, DB-aware Prompt Builder for SQL Generation)
# ----------------------------------------
from typing import List
from sql_output_parser import clean_llm_output, SQLGenerationOutput
from context import database_detail_ctx

DB_TYPE_GUIDANCE = {
    "mssql": (
        "- Use OFFSET ... FETCH NEXT ... ONLY for pagination.\n"
        "- Use WITH (NOLOCK) in joins for read-only access.\n"
        "- Prefer ISNULL(expr, default) for NULL fallback.\n"
        "- Avoid LIMIT; use TOP with caution and only with ORDER BY.\n"
        "- Use CONVERT or CAST for type casting.\n"
        "- Use square brackets [column] for reserved words or special characters.\n"
        "- For phonetic matching: Use SOUNDEX(ProjectName) = SOUNDEX('Ganga Path') for similar-sounding names.\n"
        "- Note: SIMILARITY function is not natively supported in MSSQL; use SOUNDEX or DIFFERENCE for approximate matching."
    ),
    
    "postgres": (
        "- Use LIMIT N and OFFSET N for pagination.\n"
        "- Use COALESCE(expr, default) for NULL fallback.\n"
        "- For fuzzy text matches, use SIMILARITY(ProjectName, 'Ganga Path') > 0.4 (requires pg_trgm extension).\n"
        "- Use double quotes \"column\" for case-sensitive identifiers.\n"
        "- CTEs and subqueries are encouraged.\n"
        "- Avoid MSSQL-specific syntax like NOLOCK, TOP."
    ),
    
}


# ✅ Prompt Builder
def build_sql_generation_prompt(nl_query: str, schema_str: str, business_str: str) -> List[dict]:
    print("xxxxxxxx inside SQL generation")
    try:
        db_type = database_detail_ctx.get().get("database_type", "").lower().strip()
    except Exception:
        db_type = "mssql"

    if db_type not in DB_TYPE_GUIDANCE:
        db_type = "mssql"

    db_guidance = DB_TYPE_GUIDANCE[db_type]
    #print("business details",business_str)

    system_prompt = f"""# Section 1: Role & Objective
You are an expert SQL generator for BI systems targeting {db_type.upper()}.
Translate the user's natural language question into a secure, optimized, SELECT-only SQL query.

⚠️ Only proceed if the database schema context is clearly sufficient.
⚠️ Your response must be a valid JSON object — no markdown, no SQL blocks, no explanations.
---
# Section 2A: Database Context
--- Database Context ---
Use the following schema to identify tables, columns, data types, and Table-Relationships.
✅ Always:
- Analyze **table descriptions**, **column descriptions** and **example values** to understand format and meaning.
- Use examples to choose appropriate columns for filtering or aggregation.
- Detect code/name column  pairs (e.g., `state` vs `state_code`).
Database-Specific Hints for {db_type.upper()}:
{db_guidance}

Schema with Descriptions and Examples:
{schema_str.strip()}
# --- End Database Context ---
---
# Section 2B: Business Rules
--- Business-Specific Rules ---
Always apply the following business rules where relevant:
{business_str.strip()}
# --- End Business Rules ---
✅ Examples:
- Use `DISTINCT` on identifiers when needed.
- Prefer `ReportingCurrencyAmount` over `AmountCur` unless both are necessary.
- Use `SUM()` When the query implies total or outstanding, treat ‘outstanding’ and ‘debtors outstanding’ as having the same meaning.
- **Always order results by the most important metric (e.g., aggregated amount) in `DESC` order**.
- **Always alias columns with space-separated, business-friendly names**,Never use underscores or hyphens.
- Enclose aliases in **square brackets** for compatibility.
- **Important:** If summing any amount-related column (e.g., column_name), and its data type is numeric (e.g., INT, DECIMAL), explicitly cast to `DECIMAL`:  
  `SUM(CAST(column_name AS DECIMAL(18,2))) AS total_amount`
---
# Section 3: Reasoning Chain
1. **Schema Understanding**:
   - Read both descriptions and example values.
   - Use example patterns to infer format and meaning.
2. **Query Intent**:
   - Identify the requested output, filters, date ranges, totals, rankings, or ordering.
   - Detect when aggregation is needed (e.g., total amount, outstanding or debtors outstanding, counts).
3. **Context Validation**:
   - If required tables/columns are missing → return `final_sql: null`.
4. **Filter Column Selection**:
   - Pick columns matching the user’s filter intent, based on schema patterns.
5. **Value Normalization + Fuzzy Match**:
   - Match values to column format.
   - ✅ Use SOUNDEX (MSSQL) or SIMILARITY/ILIKE (PostgreSQL) for non-name columns. use like business line columns
   - ❌ DO NOT use fuzzy match for project/manager/org names — use exact or partial matches only.
6. **Output Columns + Aggregation**:
   - Include requested data.
   - Add contextual fields (e.g., date for latest).
   - Use `SUM()`, `COUNT()`, etc. when query implies totals.
   - Always alias each column using `AS alias name` — no bare column names.
7. **Joins**:
   - Join only if required, using schema keys and Table-Relationships.
8. **Filters + WHERE**:
   - Apply precise filters using normalized values and logic from intent.
9. **ORDER BY DESC**:
   - If any rank, top, latest, or aggregate sort is implied, **apply `ORDER BY ... DESC`**.
   - Always sort by aggregated column if applicable.
10. **Optimization & Security**:
    - Avoid SELECT * — use only relevant columns.
    - Ensure SELECT-only query (no UPDATE/DELETE/INSERT).
11. **Validation**:
    - Confirm all table/column names exist.
    - Ensure aggregation and aliasing are valid and all columns are labeled meaningfully.
---
# Section 4: Output Format Specification (Simple JSON Only)
--- Output Format ---
Your **entire response** MUST be **only** the JSON object specified below. **ABSOLUTELY NO introductory text, concluding remarks, code blocks (like ```sql or ```json), explanations, apologies, or any other content should precede or follow the JSON structure.**

**If the Context Validation (Step 3 of Reasoning) determines that a valid query CAN be generated:**
Output the generated SQL query within the `final_sql` field.
{{
  "final_sql": "SELECT column1 AS alias1, COUNT(column2) AS total_count FROM table WHERE column3 = 'some_value' GROUP BY column1 ORDER BY total_count DESC;"
}}
"""

    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": nl_query.strip()}
    ]
















# # ----------------------------------------
# # 📁 sql_gen_utils.py (Prompt builder for SQL generation)
# # ----------------------------------------
# from typing import List
# from sql_output_parser import clean_llm_output, SQLGenerationOutput

# def build_sql_generation_prompt(nl_query: str, schema_str: str) -> List[dict]:
#     system_prompt = (
#         "You are an advanced SQL query generator for production-grade Business Intelligence (BI) environments, targeting Microsoft SQL Server 2022. "
#         "Your task is to translate a natural language query into an optimized, secure, and executable read-only SELECT query through systematic reasoning."
#         "\n\nFollow these steps carefully:"
#         "\n1. SCHEMA ANALYSIS: First analyze the provided database schema to understand tables, columns, relationships, and data types."
#         "\n2. QUERY INTENT: Identify the core intent of the natural language query - what information is being requested?"
#         "\n3. LOGIC CONSISTENCY: For geographic queries, maintain consistent definitions:"
#         "\n   - Delhi NCR always includes: Delhi state + these cities: Gurgaon, Noida, Faridabad, Ghaziabad, Greater Noida"
#         "\n4. TABLE MAPPING: Determine which tables contain the needed information based on the schema."
#         "\n5. JOIN STRATEGY: Plan how to join these tables using proper relationships from the schema."
#         "\n6. COLUMN SELECTION: Select appropriate columns that match the requested information."
#         "\n7. FILTER LOGIC: Implement filtering conditions that accurately reflect the query requirements."
#         "\n8. OPTIMIZATION: Apply BI optimizations (CTEs, NOLOCK, filtered joins)."
#         "\n9. SECURITY: Ensure the query is SELECT-only and avoids unsafe operations."
#         "\n10. VALIDATION: Validate all logic, column/table existence, and output naming."
#         f"\n\nDatabase Schema:\n{schema_str}"
#         "\n\nRespond in this exact JSON format:"
#         "\n{"
#         "\n  \"steps\": ["
#         "\n    {\"step\": \"Schema Analysis\", \"reasoning\": \"...\"},"
#         "\n    {\"step\": \"Query Intent\", \"reasoning\": \"...\"},"
#         "\n    ..."
#         "\n  ],"
#         "\n  \"final_sql\": \"\"\"\n  SELECT column1, column2\n  FROM table\n  WHERE condition\n  \"\"\""
#         "\n}"
#     )

#     return [
#         {"role": "system", "content": system_prompt},
#         {"role": "user", "content": nl_query.strip()}
#     ]

# # ✅ Alias for output parsing (same as error correction)
# def extract_generated_sql(raw_output: str) -> SQLGenerationOutput:
#     return SQLGenerationOutput.parse_raw(clean_llm_output(raw_output))