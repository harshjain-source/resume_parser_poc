import os
import asyncio
from elasticsearch import Elasticsearch
from dotenv import load_dotenv

load_dotenv()

es_password = os.getenv("ELASTICSEARCH_PASSWORD")
es_host = os.getenv("ELASTICSEARCH_HOST")
es_cert_path = os.getenv("ELASTICSEARCH_CA_CERT")

es = Elasticsearch(
    es_host,
    basic_auth=("elastic", es_password),
    ca_certs=es_cert_path,
)

# -------------------------
# Async Search Helper
# -------------------------
async def es_search(index_name, query):
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(None, lambda: es.search(index=index_name, body=query))
    except Exception as e:
        print(f"[ERROR] es_search failed for '{index_name}': {e}")
        return None

# -------------------------
# Search Wrapper
# -------------------------
async def search_elasticsearch(type_key, search_value, config):
    index_name = config["index"]
    field_name = config["field"]

    if not search_value or search_value.strip().lower() == "null":
        print(f"[INFO] Empty search value for '{type_key}'.")
        return None

    query = {
        "query": {
            "match": {
                field_name: {
                    "query": search_value,
                    "fuzziness": "AUTO"
                }
            }
        }
    }

    try:
        response = await es_search(index_name, query)
        if not response:
            return None

        hits = response.get("hits", {}).get("hits", [])
        return [hit["_source"][field_name] for hit in hits if field_name in hit["_source"]]
    except Exception as e:
        print(f"[ERROR] Search failed for '{type_key}': {e}")
        return [f"❌ Elasticsearch error: {str(e)}"]


# -------------------------
# Handle Multiple Searches (Index = Field = Key)
# -------------------------
async def handle_all_searches(extracted_values: dict):
    """
    extracted_values: dict of {key: value} 
    Example: {"project_name": "Gangapath", "organization_name": "ABC"}
    """

    results = {}

    for key, value in extracted_values.items():
        if not value or str(value).strip().lower() == "null":
            results[f"{key}_results"] = None
            continue

        # index and field both key name
        config = {"index": key, "field": key}

        try:
            results[f"{key}_results"] = await search_elasticsearch(key, value, config)
        except Exception as e:
            print(f"[ERROR] Search failed for {key}: {e}")
            results[f"{key}_results"] = [f"❌ Elasticsearch error: {str(e)}"]

    return results




from elasticsearch import Elasticsearch, helpers
import pyodbc
import psycopg2
import os
from dotenv import load_dotenv


def fetch_data_from_db(database_detail: dict, sql_query: str):
    db_type = database_detail["database_type"].lower()

    if db_type == "mssql":
        conn_str = (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={database_detail['host']},{database_detail['port']};"
            f"DATABASE={database_detail['database_name']};"
            f"UID={database_detail['username']};"
            f"PWD={database_detail['password']}"
        )
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()
        cursor.execute(sql_query)
        columns = [column[0] for column in cursor.description]
        rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        return rows

    elif db_type == "postgres":
        conn = psycopg2.connect(
            host=database_detail["host"],
            port=database_detail["port"],
            user=database_detail["username"],
            password=database_detail["password"],
            dbname=database_detail["database_name"]
        )
        cursor = conn.cursor()
        cursor.execute(sql_query)
        columns = [desc[0] for desc in cursor.description]
        rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        return rows

    else:
        raise ValueError(f"Unsupported database type: {db_type}")


# -------------------------
# Create Index + Insert Docs
# -------------------------
def create_index_only(database_detail: dict, search_data: dict):
    index_name = search_data["index_name"]
    field_name = search_data["index_name"]
    table = search_data["table"]
    column = search_data["column"]

    # ✅ Build SQL query dynamically
    sql_query = f"SELECT {column} FROM {table};"
    # Fetch DB data
    rows = fetch_data_from_db(database_detail, sql_query)
    if not rows:
        return {"message": "No data fetched from database."}

    # Check if index already exists
    if es.indices.exists(index=index_name):
        return {"message": f"Index '{index_name}' already exists."}

    # Create index
    es.indices.create(
        index=index_name,
        body={
            "mappings": {
                "properties": {
                    field_name: {"type": "text"}
                }
            }
        }
    )

    # Insert data
    db_field = list(rows[0].keys())[0]
    actions = [
        {"_index": index_name, "_source": {field_name: row[db_field]}}
        for row in rows if row.get(db_field)
    ]
    helpers.bulk(es, actions)

    return {
        "message": f"Index '{index_name}' created successfully.",
        "documents_indexed": len(actions)
    }


def update_index(database_detail: dict, search_data: dict):
    index_name = search_data["index_name"]
    field_name = search_data["index_name"]
    table = search_data["table"]
    column = search_data["column"]

    # ✅ Build SQL query dynamically
    sql_query = f"SELECT {column} FROM {table};"

    # Fetch data
    rows = fetch_data_from_db(database_detail, sql_query)
    if not rows:
        return {"message": "No data fetched from database."}

    # Index must exist
    if not es.indices.exists(index=index_name):
        return {"message": f"Index '{index_name}' does not exist."}

    # Insert/Update documents
    db_field = list(rows[0].keys())[0]
    actions = [
        {"_index": index_name, "_source": {field_name: row[db_field]}}
        for row in rows if row.get(db_field)
    ]

    helpers.bulk(es, actions)

    return {
        "message": f"Index '{index_name}' updated successfully.",
        "documents_indexed": len(actions)
    }

