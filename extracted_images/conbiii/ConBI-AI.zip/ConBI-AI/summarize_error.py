# ----------------------------------------
# 📁 summarize_error.py (LLM-based error summarizer for large error messages)
# ----------------------------------------

from llm import call_llm

# ✅ System prompt to instruct LLM for technical error summarization
SYSTEM_PROMPT = "You are an expert at summarizing SQL error messages into short, human-readable explanations but keep key points which will be helpful to debug."

# ✅ Max character threshold before triggering LLM
MAX_ERROR_LENGTH = 1500

# ✅ Wrapper function to optionally summarize if needed
async def summarize_error_if_needed(error_message: str) -> str:
    """
    If error_message is short, return as-is.
    If too long, use LLM to summarize.
    """
    if len(error_message) <= MAX_ERROR_LENGTH:
        return error_message.strip()

    prompt = f"The following SQL error message is long:\n{error_message}\n\nPlease summarize this error."
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": prompt.strip()}
    ]
    try:
        response = await call_llm("error_summary", messages)
        return response.strip()
    except Exception as e:
        return f"[Summarization failed] {str(e)}"

# ✅ Example usage for testing
if __name__ == "__main__":
    test_error = (
        "Error: The column 'xyz' does not exist in table 'orders'. "
        "Please check the schema for correct column names. Also verify that you have proper permissions for accessing this table."
    )
    print("Summary:", summarize_error_if_needed(test_error))
