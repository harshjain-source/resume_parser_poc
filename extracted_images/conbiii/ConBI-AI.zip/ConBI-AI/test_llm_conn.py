
import requests
from openai import OpenAI
from langchain_openai import ChatOpenAI
from groq import Groq

# Function to check OpenAI connection
def check_openai_connection(api_key: str, model: str):
    try:
        # Establish connection by listing models
        client = OpenAI(api_key=api_key)
        models = client.models.list()  # List available models
        if model in [m.id for m in models]:  # Check if the model is available
            # print(f"OpenAI connection successful for model: {model}")
            return True
        else:
            # print(f"Model {model} not available in OpenAI.")
            return False
    except Exception as e:
        # print(f"OpenAI connection failed: {e}")
        return False

# Function to check DeepInfra connection
def check_deepinfra_connection(api_key: str, model: str):
    try:
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        # Send a GET request to verify the connection and list models
        response = requests.get("https://api.deepinfra.com/v1/models", headers=headers)
        if response.status_code == 200:
            models = response.json().get("models", [])
            if model in models:
                # print(f"DeepInfra connection successful for model: {model}")
                return True
            else:
                # print(f"Model {model} not available in DeepInfra.")
                return False
        else:
            # print(f"DeepInfra connection failed with status code {response.status_code}")
            return False
    except Exception as e:
        # print(f"DeepInfra connection failed: {e}")
        return False

# Function to check Groq connection
def check_groq_connection(api_key: str, model: str):
    try:
        client = Groq(api_key=api_key)
        
        # List models to check connection
        response = client.models.list()  # Groq client returns a ModelListResponse object
        
        # Extract the models from the 'data' attribute of the response
        models = response.data if hasattr(response, 'data') else []
        
        # Print models to inspect the structure
        # print("Models returned by Groq:", models)
        
        # Iterate over the models and check the 'id' attribute
        if models and isinstance(models, list):
            for m in models:
                # Check if model is an object and has an 'id' attribute
                if hasattr(m, 'id') and model == m.id:
                    # print(f"Groq connection successful for model: {model}")
                    return True
            # print(f"Model {model} not available in Groq.")
            return False
        else:
            # print("Unexpected structure returned by Groq.")
            return False

    except Exception as e:
        # print(f"Groq connection failed: {e}")
        return False

# Function to check connection for any LLM
def test_llm_connection(api_key: str, model: str, platform: str):
    if platform.lower() == "openai":
        return check_openai_connection(api_key, model)
    elif platform.lower() == "deepinfra":
        return check_deepinfra_connection(api_key, model)
    elif platform.lower() == "groq":
        return check_groq_connection(api_key, model)
    else:
        print(f"Unsupported platform: {platform}")
        return False

if __name__ == "__main__":
    # Example usage
    api_key = "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"  # Replace with your actual API key
    model = "llama-3.3-70b-versatile"  # Replace with your actual model
    platform = "groq"  # Replace with the platform (e.g., "openai", "deepinfra", or "groq")

    # Example usage
    api_key = "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"  # Replace with your actual API key
    model = "gpt-4o"  # Replace with your actual model
    platform = "openai"  # Replace with the platform (e.g., "openai", "deepinfra", or "groq")

    # Run the connection check for the provided model and platform
    is_connected = test_llm_connection(api_key, model, platform)

    if is_connected:
        print("LLM connection successful.")
    else:
        print("LLM connection failed.")
