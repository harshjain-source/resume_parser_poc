# logger_utils.py
import json
import traceback                      # ✅ already present
from collections import deque
from datetime import datetime
from collections import OrderedDict
from contextlib import contextmanager  # ✅ already present
from typing import Optional, Any       # ✅ already present
import os                              # ✅ already present
import atexit                          # ✅ NEW (safety flush on exit)

# Latest on top (left), keep only 20
all_questions = deque(maxlen=20)


def _safe_json_dumps(data):
    """Safely convert Python objects to JSON (handle int64, Decimal, datetime, etc.)"""
    return json.dumps(data, indent=2, ensure_ascii=False, default=str)


def _ensure_current():
    """Ensure there's at least one 'current' question to attach logs to."""
    if not all_questions:
        all_questions.appendleft({"created_at": datetime.utcnow().isoformat()})
    return all_questions[0]


def log_retrieved_payload(payload: dict):
    """
    Start a NEW question record and put it on TOP as 'question-1'.
    Older ones automatically shift down. Only top 20 kept.
    """
    record = {
        "created_at": datetime.utcnow().isoformat(),
        "payload": payload,
    }
    all_questions.appendleft(record)
    save_logs()  # ✅ NEW: write immediately so early returns still create a log


def log_retrieved_schemas(logs):
    """Attach db schema hits to the CURRENT top record."""
    current = _ensure_current()
    if logs:
        current["db_schema"] = logs


def log_retrieved_business(logs):
    """Attach business rules to the CURRENT top record."""
    current = _ensure_current()
    if logs:
        current["business_rule"] = logs


def log_final_prompt(prompt: str):
    """Attach the generated final prompt to the CURRENT top record."""
    current = _ensure_current()
    if prompt:
        current["final_prompt"] = prompt


def log_retrieved_response(response):
    """
    Attach model/SQL response to CURRENT top record.
    """
    current = _ensure_current()
    current["response"] = response
    save_logs()


def log_error(err: Exception | str, *, extra: Optional[dict] = None) -> None:
    """
    Attach error info (type/message/traceback) to CURRENT record and save.
    """
    current = _ensure_current()
    if isinstance(err, Exception):
        err_dict = {
            "type": type(err).__name__,
            "message": str(err),
            "traceback": traceback.format_exc(),
        }
    else:
        err_dict = {"type": "Error", "message": str(err), "traceback": None}
    if extra:
        err_dict["extra"] = extra
    current["error"] = err_dict
    save_logs()


@contextmanager
def log_session(initial_payload: Optional[dict] = None):
    """
    Ensure a log record exists and is flushed even on 'no record' or errors.
    """
    if initial_payload is not None:
        log_retrieved_payload(initial_payload)
    else:
        _ensure_current()
    try:
        yield
    except Exception as e:
        log_error(e)
        raise
    finally:
        save_logs()


def _order_record(record: dict) -> OrderedDict:
    """Ensure keys are saved in the correct sequence."""
    ordered = OrderedDict()
    # Always keep created_at first
    if "created_at" in record:
        ordered["created_at"] = record["created_at"]
    # Then follow the sequence
    for key in ["payload", "db_schema", "business_rule", "final_prompt", "response", "error"]:
        if key in record:
            ordered[key] = record[key]
    return ordered


def save_logs():
    """
    Save latest <=20 questions to JSON, with NEWEST numbered as question-1,
    next as question-2, ... while preserving key sequence.
    """
    ordered = OrderedDict()
    for idx, record in enumerate(all_questions, start=1):
        # ✅ NEW: ensure every record has a response block
        if "response" not in record:
            if "error" in record:
                record["response"] = {"message": "Error occurred", "data": []}
            else:
                record["response"] = {"message": "No records found or something went wrong", "data": []}

        ordered[f"question-{idx}"] = _order_record(record)

    log_path = os.getenv("LOGS_JSON_PATH", "all_logs.json")
    with open(log_path, "w", encoding="utf-8") as f:
        f.write(_safe_json_dumps(ordered))


# ✅ NEW: safety flush so even abrupt/early returns persist logs
atexit.register(save_logs)
