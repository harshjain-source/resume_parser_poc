import requests
from openai import OpenAI
from langchain_openai import ChatOpenAI

# Need imports for async versions and httpx
from openai import AsyncOpenAI      # Use AsyncOpenAI
from langchain_openai import ChatOpenAI # Assuming langchain setup is correct
import httpx                      # Use httpx for async requests instead of requests
from groq import AsyncGroq        # Use AsyncGroq


from context import (
    summary_model_ctx, sql_gen_model_ctx, query_refiner_model_ctx,
    error_correction_model_ctx, unspecialized_model_ctx, error_summary_model_ctx
)

def get_task_config(task_type: str) -> dict:
    """Fetch the correct config for the requested LLM task."""
    if task_type == "summary":
        return summary_model_ctx.get()
    elif task_type == "sql_gen":
        return sql_gen_model_ctx.get()
    elif task_type == "query_refiner":
        return query_refiner_model_ctx.get()
    elif task_type == "error_correction":
        return error_correction_model_ctx.get()
    elif task_type == "unspecialized":
        return unspecialized_model_ctx.get()
    elif task_type == "error_summary":
        return error_summary_model_ctx.get()
    else:
        raise ValueError(f"Unsupported LLM task type: {task_type}")







async def call_llm(type_of_task: str, messages: list) -> str:
    """
    Calls the LLM asynchronously based on type and message history.

    Args:
        type_of_task (str): One of 'summary', 'sql_gen', 'query_refiner', 'error_correction', 'unspecialized'
        messages (list): A list of OpenAI-style message dicts

    Returns:
        str: The LLM response content

    Raises:
        Exception: Propagates any exception encountered during configuration or API call.
        ValueError: If the platform is unsupported.
    """
    # Config loading remains synchronous (assuming get_task_config is sync)
    # Wrapping this is still good practice.
    print("8",type_of_task)
    try:
        print("9")
        config = get_task_config(type_of_task)
        model = config["name"]
        platform = config["platform"].lower()
        api_key = config["api_key"]
    except Exception as e:
        print("$$$$$$$$ 10",e)
        # Re-raise config errors immediately
        raise Exception(f"Failed to get configuration for task '{type_of_task}': {e}") from e

    # The main try...except logic remains the same, only calls inside change
    try:
        print("11",type_of_task)
        if platform == "openai":
            print("12")
            if model == "o3-mini": # Assuming o3-mini uses the standard client
                print("12.1")
                # Use AsyncOpenAI client
                client = AsyncOpenAI(api_key=api_key)
                # Use 'await' for the async API call
                response = await client.chat.completions.create(
                    model=model,
                    messages=messages,
                )
                return response.choices[0].message.content.strip()
            else:
                print("12.2")
                # Instantiate ChatOpenAI (remains synchronous)
                llm = ChatOpenAI(model=model, openai_api_key=api_key, temperature=0)
                # Use 'await' and the async 'ainvoke' method for Langchain
                response = await llm.ainvoke(messages)
                print("12.3")
                return response.content.strip()

        elif platform == "deepinfra":
            # Headers remain the same
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            # Payload remains the same
            payload = {
                "model": model,
                "messages": messages
            }
            # Use httpx.AsyncClient for async HTTP POST request
            async with httpx.AsyncClient() as client:
                # Use 'await' for the async post call
                response = await client.post(
                    "https://api.deepinfra.com/v1/openai/chat/completions",
                    headers=headers,
                    json=payload
                )
            # Check status code (httpx raises HTTPStatusError)
            response.raise_for_status()
            # Response parsing remains the same
            return response.json()["choices"][0]["message"]["content"].strip()

        elif platform == "groq":
            # Use AsyncGroq client
            client = AsyncGroq(api_key=api_key)
            # Use 'await' for the async API call
            response = await client.chat.completions.create(
                model=model,
                messages=messages
            )
            # Response parsing remains the same
            return response.choices[0].message.content.strip()

        else:
            # Logic remains the same
            raise ValueError(f"Unsupported LLM platform: {platform}")

    except Exception as e:
        print("13 Exception", e)
        # Error handling logic remains exactly the same: simply re-raise
        raise e
    print("testing end of line")


# Example usage for testing the o3-mini branch:
if __name__ == "__main__":
    # Test error correction using o3-mini
    platform = "openai"  # For error correction, platform is forced to OpenAI.
    type_of_task = "error_correction_model"  # This triggers the o3-mini branch.
    user_query = "Fix the error in the query: SELECT * FROM customer where id = 1;"
    messages = [
        {"role": "system", "content": "You are an expert SQL query fixer."},
        {"role": "user", "content": user_query}
    ]
    
    response = call_llm(platform, type_of_task, messages)
    print("O3-mini Error Correction Response:\n", response)








############################################################################################











# import requests
# from langchain_openai import ChatOpenAI

# # API Keys and model settings (replace with your actual keys)
# OPENAI_API_KEY = "YOUR_OPENAI_API_KEY"
# DEEPINFRA_API_KEY = "YOUR_DEEPINFRA_API_KEY"
# DEEPINFRA_MODEL = "google/gemma-3-27b-it"
# GROQ_API_KEY = "YOUR_GROQ_API_KEY"
# GROQ_MODEL = "llama-3.3-70b-versatile"

# summary_model = "google/gemma-3-27b-it"
# sql_gen_model = "google/gemma-3-27b-it"
# query_correction_model = "google/gemma-3-27b-it"


# def call_llm(platform, type_of_task, message):
#     """
#     Call an LLM based on the platform, type of task, and message.

#     Parameters:
#         platform (str): "openai", "deepinfra", or "groq".
#         type_of_task (str): A description of the task (e.g., "text generation").
#         message (str): The user message.

#     Returns:
#         str: The response from the LLM.
#     """

    
#     if platform.lower() == "openai":
#         llm = ChatOpenAI(model="gpt-4o", openai_api_key=OPENAI_API_KEY, temperature=0)
#         response = llm.invoke(messages)
#         return response.content

#     elif platform.lower() == "deepinfra":
#         headers = {
#             "Authorization": f"Bearer {DEEPINFRA_API_KEY}",
#             "Content-Type": "application/json",
#         }
#         payload = {
#             "model": DEEPINFRA_MODEL,
#             "messages": messages
#         }
#         api_url = "https://api.deepinfra.com/v1/openai/chat/completions"
#         response = requests.post(api_url, headers=headers, json=payload)
#         if response.status_code == 200:
#             return response.json()["choices"][0]["message"]["content"].strip()
#         else:
#             raise Exception(f"DeepInfra Error: {response.status_code}, {response.text}")

#     elif platform.lower() == "groq":
#         from groq import Groq
#         client = Groq(api_key=GROQ_API_KEY)
#         chat_completion = client.chat.completions.create(
#             messages=messages,
#             model=GROQ_MODEL,
#         )
#         return chat_completion.choices[0].message.content.strip()
    
#     else:
#         raise ValueError("Unsupported platform. Please choose 'openai', 'deepinfra', or 'groq'.")

# # Example usage:
# if __name__ == "__main__":
#     platform = "openai"  # Options: "openai", "deepinfra", "groq"
#     type_of_task = "text generation"
#     message = "Generate a sample text for our marketing campaign."
    
#     response = call_llm(platform, type_of_task, message)
#     print("LLM Response:\n", response)



########################################################################

