from fastapi import FastAPI
from summary_utils import STATIC_SYSTEM_PROMPT, DEFAULT_DYNAMIC_PART
from pathlib import Path
import json
from pydantic import BaseModel
from typing import Optional

app = FastAPI()

PROMPT_FILE_PATH = Path("Output_prompt/system_prompts.json")


# ---------------------------
# Allow partial updates
# ---------------------------
class PromptUpdateRequest(BaseModel):
    STATIC_SYSTEM_PROMPT: Optional[str] = None
    DEFAULT_DYNAMIC_PART: Optional[str] = None


@app.get("/")
def read_root():
    return {"Hello": "World", "message": "Welcome to FastAPI!"}


@app.get("/items/{item_id}")
def read_item(item_id: int, q: str | None = None):
    return {"item_id": item_id, "q": q}


# ---------------------------
# GET – Read prompts
# ---------------------------
@app.get("/prompts")
def get_prompts():
    if not PROMPT_FILE_PATH.exists():
        return {
            "message": "system_prompts.json not found"
        }

    return json.loads(
        PROMPT_FILE_PATH.read_text(encoding="utf-8")
    )


# @app.post("/api/prompts")
# def update_prompts():
#     # updates = payload.data.dict(exclude_none=True) if payload.data else {}

#     # # 🚫 Case 1: Empty payload → ERROR (no silent override)
#     # if not updates:
#     #     return {
#     #         "error": "No prompt fields provided. Nothing to update."
#     #     }

#     # 🟢 Case 2: File does NOT exist → initialize with defaults
#     if not PROMPT_FILE_PATH.exists():
#         data = {
#             "STATIC_SYSTEM_PROMPT": STATIC_SYSTEM_PROMPT,
#             "DEFAULT_DYNAMIC_PART": DEFAULT_DYNAMIC_PART,
#         }
#     else:
#         # 🟡 Case 3: File exists → load existing (KEEP AS-IS)
#         try:
#             data = json.loads(PROMPT_FILE_PATH.read_text(encoding="utf-8"))
#         except Exception:
#             return {
#                 "error": "system_prompts.json is corrupted. Fix or reset manually."
#             }

#     # 🟢 Override ONLY what client explicitly sends
#     if "STATIC_SYSTEM_PROMPT" in updates:
#         if not updates["STATIC_SYSTEM_PROMPT"].strip():
#             return {
#                 "error": "STATIC_SYSTEM_PROMPT cannot be empty"
#             }
#         data["STATIC_SYSTEM_PROMPT"] = updates["STATIC_SYSTEM_PROMPT"].strip()

#     if "DEFAULT_DYNAMIC_PART" in updates:
#         if not updates["DEFAULT_DYNAMIC_PART"].strip():
#             return {
#                 "error": "DEFAULT_DYNAMIC_PART cannot be empty"
#             }
#         data["DEFAULT_DYNAMIC_PART"] = updates["DEFAULT_DYNAMIC_PART"].strip()

#     # ✍️ Write back safely
#     PROMPT_FILE_PATH.write_text(
#         json.dumps(data, indent=2, ensure_ascii=False),
#         encoding="utf-8"
#     )

#     return {
#         "message": "Prompts updated successfully",
#         "updated_fields": list(updates.keys()),
#         "file": str(PROMPT_FILE_PATH)
#     }


@app.post("/prompts")
def update_prompts(payload: PromptUpdateRequest):
    payload_dict = payload.dict(exclude_none=True)

    # 🟢 CASE 1: Empty body → RESET TO DEFAULTS
    if not payload_dict:
        return {
         "error": "No prompt fields provided. Nothing to update."
        }
    # 🟢 Case 2: File does NOT exist → initialize with defaults
    if not PROMPT_FILE_PATH.exists():
        data = {
            "STATIC_SYSTEM_PROMPT": STATIC_SYSTEM_PROMPT,
            "DEFAULT_DYNAMIC_PART": DEFAULT_DYNAMIC_PART,
        }
    else:
        # 🟡 Case 3: File exists → load existing (KEEP AS-IS)
        try:
            data = json.loads(PROMPT_FILE_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {
                "error": "system_prompts.json is corrupted. Fix or reset manually."
            }

    # Override only what client sends
    if payload.STATIC_SYSTEM_PROMPT:
        data["STATIC_SYSTEM_PROMPT"] = payload.STATIC_SYSTEM_PROMPT.strip()

    if payload.DEFAULT_DYNAMIC_PART:
        data["DEFAULT_DYNAMIC_PART"] = payload.DEFAULT_DYNAMIC_PART.strip()

    PROMPT_FILE_PATH.write_text(
        json.dumps(data, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

    return {
        "message": "Prompts updated successfully",
        "source": "client + defaults",
        "file": str(PROMPT_FILE_PATH)
    }
