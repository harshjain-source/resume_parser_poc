# ----------------------------------------
# 📁 context_middleware.py (ContextVar Reset Middleware)
# ----------------------------------------
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

from context import (
    chat_history_ctx, curr_user_query_ctx, database_detail_ctx,index_list_ctx,
    retrieved_db_schema_for_query_ctx, query_response_ctx,
    main_model_ctx, summary_model_ctx, sql_gen_model_ctx,
    query_refiner_model_ctx, error_correction_model_ctx, error_summary_model_ctx, fastapi_response_ctx,
    unspecialized_model_ctx, error_sql_attempts_ctx  # ✅ newly added
)

class ResetContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # 🧼 Reset all ContextVars at the beginning of every request
        chat_history_ctx.set([])
        index_list_ctx.set([]) # ✅ reset index list
        curr_user_query_ctx.set("")
        database_detail_ctx.set({})
        retrieved_db_schema_for_query_ctx.set("")
        query_response_ctx.set({
            "original_query": "",
            "total_refined_query": 0,
            "refined_query_list": [],
            "query_sql_answer": [],
            "summary": ""
        })
        main_model_ctx.set({})
        summary_model_ctx.set({})
        sql_gen_model_ctx.set({})
        query_refiner_model_ctx.set({})
        error_correction_model_ctx.set({})
        unspecialized_model_ctx.set({})
        error_summary_model_ctx.set({})
        error_sql_attempts_ctx.set({})  # ✅ reset failed SQL attempts
        fastapi_response_ctx.set({})

        # ⏩ Continue to request handling
        response = await call_next(request)
        return response
