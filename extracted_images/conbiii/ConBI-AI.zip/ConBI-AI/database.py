# --- Required ASYNC Library Imports ---
import asyncpg  # For PostgreSQL
import aioodbc  # For MSSQL (and other ODBC)
import asyncio  # For event loop if running standalone

# --- Original Imports (Keep All) ---
import pyodbc # No longer used directly for connect/execute, but keep if needed elsewhere? Aioodbc uses it underneath.
import psycopg2 # No longer used directly for connect/execute
# import mysql.connector
# from pymongo import MongoClient
# --- Assuming 'context' provides config synchronously ---
# If database_detail_ctx itself becomes async, its usage needs 'await' too
from context import database_detail_ctx
import json
import decimal
import datetime
import uuid
import base64
from typing import List, Dict, Any, Optional

# --- Placeholder for Config Fetching (Assumed Synchronous based on original) ---
def get_db_config(db_type: str) -> Dict[str, Any]:
    """Fetches config details. Replace with your actual implementation."""
    config_all = database_detail_ctx.get() # Assuming this call is sync
    if db_type == "postgres":
        # Extract PG specific details if necessary
        return config_all
    elif db_type == "mssql":
        # Extract MSSQL specific details if necessary
        return config_all
    return {} # Should not happen if called correctly

# --- Optional Custom Error ---
class DatabaseQueryError(Exception):
    """Custom exception for query execution errors."""
    pass

# --- Async Connection Handlers (Converted from Sync) ---

async def connect_postgres() -> asyncpg.Connection:
    """Establishes an async connection to PostgreSQL using asyncpg."""
    config = get_db_config("postgres")
    try:
        conn = await asyncpg.connect(
            host=config["host"],
            port=int(config.get("port", 5432)),
            database=config["database_name"], # asyncpg uses 'database'
            user=config["username"],
            password=config["password"]
        )
        return conn
    except Exception as e:
        # Log properly in production
        print(f"Error connecting to PostgreSQL (async): {e}")
        raise ConnectionError(f"PostgreSQL async connection failed: {e}") from e

async def connect_mssql() -> aioodbc.Connection:
    """Establishes an async connection to MSSQL using aioodbc."""
    config = get_db_config("mssql")
    try:
        params = {
            "DRIVER": config.get("driver", "{ODBC Driver 17 for SQL Server}"),
            "SERVER": config["host"],
            "DATABASE": config["database_name"],
            "UID": config["username"],
            "PWD": config["password"],
            "TrustServerCertificate": "yes"
        }
        conn_str = ";".join(f"{k}={v}" for k, v in params.items())
        conn = await aioodbc.connect(
            dsn=conn_str,
            loop=asyncio.get_event_loop() # Often required
        )
        return conn
    except Exception as e:
        # Log properly in production
        print(f"Error connecting to MSSQL (async): {e}")
        raise ConnectionError(f"MSSQL async connection failed: {e}") from e

# --- Async Query Execution Functions (Original Logic + Async IO) ---

async def execute_mssql_query(query: str) -> List[Dict[str, Any]]:
    """
    Connects asynchronously, executes an MSSQL query, processes results with
    original type conversions exactly, and closes the connection.
    """
    conn: Optional[aioodbc.Connection] = None # For finally block
    try:
        # --- Connects internally (async version) ---
        conn = await connect_mssql()
        # --- Uses async cursor context manager ---
        async with await conn.cursor() as cursor:
            # --- Awaits execution ---
            await cursor.execute(query)

            # --- EXACT original logic for checking results ---
            if cursor.description is None:
                # Keep original warning print
                print(f"Warning: Query '{query[:100]}...' did not return columns.")
                return [] # Return empty list

            columns = [desc[0] for desc in cursor.description]
            # --- Awaits fetching ---
            rows = await cursor.fetchall()

            results = []
            for row in rows:
                row_dict = {}
                # --- EXACT original logic for row processing and type conversion ---
                for col, val in zip(columns, row):
                    # --- Conversion Checks ---
                    if isinstance(val, decimal.Decimal):
                        val = str(val)  # Convert Decimal to string
                    elif isinstance(val, datetime.time):
                        val = val.isoformat() # Convert Time to ISO string "HH:MM:SS..."
                    elif isinstance(val, datetime.date):
                        val = val.isoformat() # Convert Date/Datetime to ISO string "YYYY-MM-DD..."
                    elif isinstance(val, uuid.UUID):
                        val = str(val) # Convert UUID to standard hyphenated string
                    elif isinstance(val, bytes):
                        val = base64.b64encode(val).decode('ascii')
                    # --- End Conversion Checks ---
                    row_dict[col] = val
                results.append(row_dict)

            # await conn.commit() # Use await if commit is needed

            return results

    except aioodbc.Error as e:
        # Log properly in production
        print(f"Aioodbc Error during query execution: {e}")
        # Raise a more specific error or let it propagate depending on desired handling
        raise DatabaseQueryError(f"MSSQL query failed: {e}") from e
    # Allow ConnectionError to propagate from connect_mssql()
    finally:
        # --- Ensure connection is closed ---
        if conn:
            await conn.close()

async def execute_postgres_query(query: str) -> List[Dict[str, Any]]:
    """
    Connects asynchronously, executes a PostgreSQL query, processes results with
    original type conversions exactly, and closes the connection.
    """
    conn: Optional[asyncpg.Connection] = None # For finally block
    try:
        # --- Connects internally (async version) ---
        conn = await connect_postgres()

        # --- Awaits fetch (returns list of Records) ---
        rows: List[asyncpg.Record] = await conn.fetch(query)

        # --- EXACT original logic adapted slightly for asyncpg result ---
        # Check if rows were returned (equivalent to description check)
        if not rows:
            # Keep original warning print (slightly adapted message)
            print(f"Warning: Query '{query[:100]}...' did not return rows.")
            return [] # Return empty list

        # Get column names from the first record's keys
        columns = list(rows[0].keys())

        results = []
        for row in rows:
            row_dict = {}
            # --- EXACT original logic for row processing and type conversion ---
            # Iterate columns by name and access record like a dictionary
            for col in columns:
                val = row[col]
                # --- Conversion Checks ---
                if isinstance(val, decimal.Decimal):
                    val = str(val)  # Convert Decimal to string
                elif isinstance(val, datetime.time):
                    val = val.isoformat() # Convert Time to ISO string "HH:MM:SS..."
                elif isinstance(val, datetime.date):
                    val = val.isoformat() # Convert Date/Datetime to ISO string "YYYY-MM-DD..."
                elif isinstance(val, uuid.UUID):
                    val = str(val) # Convert UUID to standard hyphenated string
                elif isinstance(val, bytes):
                    val = base64.b64encode(val).decode('ascii')
                # --- End Conversion Checks ---
                row_dict[col] = val

            results.append(row_dict)

        # No conn.commit() needed for SELECT queries normally

        return results

    except asyncpg.PostgresError as e:
        # Log properly in production
        print(f"Asyncpg Error during query execution: {e}")
        # Raise a more specific error or let it propagate
        raise DatabaseQueryError(f"PostgreSQL query failed: {e}") from e
    # Allow ConnectionError to propagate from connect_postgres()
    finally:
        # --- Ensure connection is closed ---
        if conn:
            await conn.close()
