# logs_view.py (updated)
import os
import json
from pathlib import Path
from typing import Any, Dict, List, Union
import html as html_lib

# Default all_logs.json path (can override via env LOGS_JSON_PATH)
DEFAULT_LOG_PATH = Path(__file__).parent / "all_logs.json"


def get_log_path() -> Path:
    """Return the JSON log path from env or default."""
    env_path = os.getenv("LOGS_JSON_PATH")
    return Path(env_path) if env_path else DEFAULT_LOG_PATH


def load_json_file(path: Path) -> Union[Dict[str, Any], List[Any], Any]:
    """Read all_logs.json and return parsed JSON."""
    if not path.exists():
        raise FileNotFoundError(
            f"JSON file not found at {path.resolve()}.\n"
            "Set LOGS_JSON_PATH env or place all_logs.json next to logs_view.py."
        )
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _extract_heading(details: dict) -> str:
    """
    Pick the best human-readable question/title from a question record.
    Priority order:
      1) payload.data.curr_user_query
      2) response.data.original_query
      3) last chat_history.original_query
      4) first response.data.refined_query_list item
      5) (fallback) the first 'user' message in final_prompt
      6) 'Untitled question'
    """
    try:
        v = (
            details.get("payload", {})
                   .get("data", {})
                   .get("curr_user_query")
        )
        if v:
            return str(v)
    except Exception:
        pass

    try:
        v = (
            details.get("response", {})
                   .get("data", {})
                   .get("original_query")
        )
        if v:
            return str(v)
    except Exception:
        pass

    try:
        ch = (
            details.get("payload", {})
                   .get("data", {})
                   .get("chat_history") or []
        )
        if isinstance(ch, list) and ch:
            last = ch[-1]
            v = last.get("original_query")
            if v:
                return str(v)
    except Exception:
        pass

    try:
        rql = (
            details.get("response", {})
                   .get("data", {})
                   .get("refined_query_list")
        )
        if isinstance(rql, list) and rql:
            return str(rql[0])
    except Exception:
        pass

    # NEW: look into final_prompt for the first user message as a decent title
    try:
        fp = details.get("final_prompt")
        if isinstance(fp, list):
            for m in fp:
                if isinstance(m, dict) and m.get("role") == "user":
                    c = m.get("content")
                    if c:
                        return str(c).strip()[:240]
    except Exception:
        pass

    return "Untitled question"


def _render_kv_table(d: Dict[str, Any]) -> str:
    """Render dict as a small Key/Value table (pretty-print nested)."""
    html = (
        "<div class='table-responsive'><table class='table table-sm table-hover table-bordered'>"
        "<thead><tr><th>Key</th><th>Value</th></tr></thead><tbody>"
    )
    for k, v in d.items():
        if isinstance(v, (dict, list)):
            v_json = json.dumps(v, indent=2, ensure_ascii=False)
            v_json = html_lib.escape(v_json)
            html += f"<tr><td>{html_lib.escape(str(k))}</td><td><pre>{v_json}</pre></td></tr>"
        else:
            html += (
                f"<tr><td>{html_lib.escape(str(k))}</td>"
                f"<td>{html_lib.escape(str(v))}</td></tr>"
            )
    html += "</tbody></table></div>"
    return html


def _render_list_table(rows: List[Dict[str, Any]]) -> str:
    """Render a list[dict] as a full table."""
    headers = list(rows[0].keys())
    html = (
        "<div class='table-responsive'><table class='table table-striped table-bordered'>"
        "<thead><tr>"
        + "".join(f"<th>{html_lib.escape(str(h))}</th>" for h in headers)
        + "</tr></thead><tbody>"
    )
    for row in rows:
        html += "<tr>" + "".join(
            f"<td>{html_lib.escape(str(row.get(h, '')))}</td>" for h in headers
        ) + "</tr>"
    html += "</tbody></table></div>"
    return html


def _render_final_prompt_block(final_prompt: Any) -> str:
    """
    Render `final_prompt` specifically.
    Accepts:
      - list of {role, content}
      - string (fallback)
      - anything else → pretty JSON
    """
    # Styles for role badges
    role_to_badge = {
        "system": "bg-secondary",
        "user": "bg-primary",
        "assistant": "bg-success",
        "tool": "bg-dark",
        "developer": "bg-warning text-dark",
    }

    if isinstance(final_prompt, list) and final_prompt and all(isinstance(m, dict) for m in final_prompt):
        out = ["<div class='final-prompt'>"]
        for idx, msg in enumerate(final_prompt, start=1):
            role = str(msg.get("role", "message")).lower()
            content = msg.get("content", "")
            badge = role_to_badge.get(role, "bg-info text-dark")

            # Safe render content; allow long text with pre-wrap
            if isinstance(content, (dict, list)):
                content_str = json.dumps(content, indent=2, ensure_ascii=False)
            else:
                content_str = str(content)

            out.append(f"""
                <div class="card mb-2 shadow-sm">
                  <div class="card-header d-flex justify-content-between align-items-center">
                    <span class="badge {badge}">{html_lib.escape(role)}</span>
                    <span class="text-muted small">#{idx}</span>
                  </div>
                  <div class="card-body">
                    <pre style="white-space: pre-wrap; word-wrap: break-word; margin:0;">{html_lib.escape(content_str)}</pre>
                  </div>
                </div>
            """)
        out.append("</div>")
        return "".join(out)

    if isinstance(final_prompt, str):
        # Single big block
        return f"<pre>{html_lib.escape(final_prompt)}</pre>"

    # Fallback: JSON dump any other structure
    dumped = json.dumps(final_prompt, indent=2, ensure_ascii=False)
    return f"<pre>{html_lib.escape(dumped)}</pre>"


def build_html_from_data(data: Union[Dict[str, Any], List[Any], Any]) -> str:
    """Build Bootstrap Accordion HTML showing actual question as heading and special render for final_prompt."""
    html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>📊 Logs Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body { background: #f8f9fa; font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; }
        h1 { text-align: center; margin: 20px; color: #333; }
        .card { margin-bottom: 20px; border-radius: 12px; }
        .card-header { cursor: pointer; background: #007bff; color: white; }
        .card-header:hover { background: #0056b3; }
        .accordion-button.card-header { box-shadow: none; }
        pre { background: #272822; color: #f8f8f2; padding: 10px; border-radius: 6px; overflow-x: auto; }
        table { margin-top: 10px; }
        th { background: #007bff; color: white; }
        .section-title { font-weight: bold; margin-top: 15px; color: #444; }
        .meta { font-size: 0.9rem; opacity: 0.85; }
        code { background: #eef1f5; padding: 2px 6px; border-radius: 6px; }
        .final-prompt .card-header { background: #f1f3f5; color: #333; }
        .badge { font-size: 0.85rem; }
    </style>
</head>
<body>
    <div class="container">
        <h1>📑 Interactive Logs Dashboard</h1>
        <div class="accordion" id="logsAccordion">
"""
    # Normalize to dict for consistent iteration
    if not isinstance(data, dict):
        data = {"Logs": data}

    qid = 1
    for q_key, details in data.items():
        # Visible heading = actual question from record
        details_dict = details if isinstance(details, dict) else {}
        heading_text = _extract_heading(details_dict)
        heading_safe = html_lib.escape(heading_text)

        # Small meta to show original key like "question-1"
        key_safe = html_lib.escape(str(q_key))

        html_content += f"""
        <div class="accordion-item card">
            <h2 class="accordion-header" id="heading{qid}">
                <button class="accordion-button collapsed card-header" type="button"
                        data-bs-toggle="collapse" data-bs-target="#collapse{qid}"
                        aria-expanded="false" aria-controls="collapse{qid}">
                    ❓ {heading_safe}
                </button>
            </h2>
            <div id="collapse{qid}" class="accordion-collapse collapse"
                 aria-labelledby="heading{qid}" data-bs-parent="#logsAccordion">
                <div class="accordion-body">
                    <div class="meta mb-2">Key: <code>{key_safe}</code></div>
        """

        # Render each top-level section within this question item
        if isinstance(details, dict):
            for section, content in details.items():
                section_safe = html_lib.escape(str(section))
                html_content += f'<div class="section"><h5 class="section-title">{section_safe}</h5>'

                # SPECIAL CASE: final_prompt
                if section == "final_prompt":
                    html_content += _render_final_prompt_block(content)
                    html_content += "</div>"
                    continue

                # Lists
                if isinstance(content, list):
                    if content and isinstance(content[0], dict):
                        html_content += _render_list_table(content)
                    else:
                        html_content += "<ul>" + "".join(
                            f"<li>{html_lib.escape(str(item))}</li>" for item in content
                        ) + "</ul>"

                # Dicts
                elif isinstance(content, dict):
                    html_content += _render_kv_table(content)

                # Primitives or HTML snippets
                else:
                    content_str = str(content)
                    # Allow trusted HTML summaries (e.g., <h3>...</h3>) to render
                    if content_str.startswith("<h3>"):
                        html_content += content_str
                    else:
                        html_content += f"<pre>{html_lib.escape(content_str)}</pre>"

                html_content += "</div>"

        else:
            # details is a primitive or a list/dict; render directly
            if isinstance(details, (list, dict)):
                v_json = json.dumps(details, indent=2, ensure_ascii=False)
                html_content += f"<pre>{html_lib.escape(v_json)}</pre>"
            else:
                html_content += f"<pre>{html_lib.escape(str(details))}</pre>"

        html_content += """
                </div>
            </div>
        </div>
        """
        qid += 1

    html_content += """
        </div>
    </div>
</body>
</html>
"""
    return html_content
