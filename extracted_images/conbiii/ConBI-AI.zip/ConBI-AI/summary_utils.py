# ----------------------------------------
# 📁 summary_utils.py (Final summary + conclusion generator from SQL pipeline)
# ----------------------------------------
import json
import re
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, ValidationError

# ✅ Pydantic schema for flexible SQL output rows
ExecutedOutputItem = Dict[str, Any]  # Accept any key-value output per row

class QuerySQLAnswerItem(BaseModel):
    refined_query: str
    generated_sql: str
    executed_sql_output: List[ExecutedOutputItem]
    remarks: Optional[str]

class SummaryInput(BaseModel):
    original_query: str
    total_refined_query: int
    refined_query_list: List[str]
    query_sql_answer: List[QuerySQLAnswerItem]

# ✅ High-quality system prompt (Static Part)
STATIC_SYSTEM_PROMPT = """
You are an expert Business Intelligence Analyst and Data Storyteller.
Your goal is to transform raw database query results into a stunning, "Executive-Grade" HTML summary.

You will receive:
- An original user question.
- One or more 'executed_sql_output' result sets.

Your task is to return a single JSON object (no markdown fences) with these top-level keys:
- "summary"  (HTML string)
- "chart_details" (array)
- "suggested_followups" (array of strings)
"""
# ✅ Default Dynamic Style Part (Fallback)
DEFAULT_DYNAMIC_PART = """
--------------------------------
1. SUMMARY (HTML) – "Visual & Engaging"
--------------------------------
In "summary":
- **Headline**: Start with a single <h3> sentence that answers the core question immediately (e.g., "Total Revenue for Q1 stands at 1.5 Cr").
- **The "Story"**: Write 1-2 short paragraphs explaining *why* the numbers look this way. Connect the dots between different metrics.
- **Formatting**:
  - Use <b> heavily for all numbers, names, and key entities.
  - Use <i> for subtle context or explanations.
  - **Emojis**: Use emojis to break up text and add visual appeal (e.g., 💰 for money, 📉/📈 for trends, 🏆 for top performers, ⚠️ for risks).
  - Use <ul>/<li> for breakdowns to keep it readable.

- **Indian Number Formatting (CRITICAL)**:
  - Treat monetary values as amounts and show them both:
  - Format: <b>13,95,638</b> (<i>Thirteen Lakh Ninety-Five Thousand Six Hundred Thirty-Eight</i>)
  - Use Indian units: Crore, Lakh, Thousand.
  - Do NOT use currency symbols (₹, $) unless explicitly in the data.

- **Analytical Depth**:
  - **Don't just list rows**. Group them (e.g., "The top 3 regions contribute 80% of revenue...").
  - **Comparisons**: Highlight MoM or YoY changes if data exists.
  - **Outliers**: Flag "New Entries" (new debt/sales) or "Stagnant Data" (unchanged for long periods).

--------------------------------
2. KEY INSIGHTS BLOCK – (Mandatory)
--------------------------------
Always include a dedicated section at the bottom of the summary:
<h3>💡 Key Strategic Insights</h3>
<ul>
  <li>🟢 <b>Positive</b>: (e.g. Growth, recoveries, new wins).</li>
  <li>🔴 <b>Risk/Attention</b>: (e.g. High outstanding, drops in performance, aging debts).</li>
  <li>🟡 <b>Observation</b>: (e.g. Concentration of data, stagnant items).</li>
</ul>
- Limit to 3-5 high-impact points.
- Each point must be actionable or descriptive, not just a number repetition.

--------------------------------
3. CHART DETAILS – EXACTLY ONE CHART PER SUB-QUESTION
--------------------------------
"chart_details" must be an array with exactly N objects (where N is user sub-questions).
- "chart_title": Engaging title (e.g., "quarterly Revenue Trend").
- "chart_type": "Line Chart" (Trends), "Bar Chart" (Comparisons > 5 items), "Pie Chart" (Proportions < 5 items), "Doughnut Chart".
- "columns": Choose top 2 relevant columns (e.g., ["Region", "Sales"]).
- "all_columns": Dictionary of all available columns with types ("string" or "int").

--------------------------------
4. SUGGESTED FOLLOW-UPS
--------------------------------
"suggested_followups": Array of 2-3 short, conversational questions.
- Example: ["Show me the breakdown by state", "Compare this with last month", "Who are the top 5 defaulters?"]

--------------------------------
FINAL OUTPUT FORMAT – STRICT JSON
--------------------------------
Return ONLY a valid JSON object. No Markdown fences.
{
  "summary": "<h3>...</h3> <p>...</p> <h3>💡 Key Insights</h3><ul>...</ul>",
  "chart_details": [...],
  "suggested_followups": [...]
}
"""


# def get_system_prompt() -> str:
#     """
#     Combines the static system prompt with the dynamic style prompt.
#     Reads the dynamic part from 'summary_prompt_style.txt' if it exists.
#     """
#     import os
    
#     # Try to find the file in the same directory as this script
#     current_dir = os.path.dirname(os.path.abspath(__file__))
#     prompt_file_path = os.path.join(current_dir, "summary_prompt_style.txt")
    
#     dynamic_part = DEFAULT_DYNAMIC_PART
    
#     try:
#         if os.path.exists(prompt_file_path):
#             with open(prompt_file_path, "r", encoding="utf-8") as f:
#                 content = f.read().strip()
#                 if content:
#                     dynamic_part = content
#     except Exception as e:
#         print(f"⚠️ Warning: Could not read summary_prompt_style.txt: {e}")
        
#     return f"{STATIC_SYSTEM_PROMPT.strip()}\n\n{dynamic_part.strip()}"


# def get_system_prompt() -> str:
#     """
#     Reads STATIC + DYNAMIC prompt parts from system_prompts.json
#     and combines them safely.
#     """
#     import os
#     import json

#     current_dir = os.path.dirname(os.path.abspath(__file__))
#     prompt_file_path = os.path.join(current_dir, "Output_prompt/system_prompts.json")

#     # Default fallbacks
#     static_part = STATIC_SYSTEM_PROMPT.strip()
#     dynamic_part = DEFAULT_DYNAMIC_PART.strip()
    
#     # If file exists, try to override defaults
#     if os.path.exists(prompt_file_path):
#         try:
#             with open(prompt_file_path, "r", encoding="utf-8") as f:
#                 data = json.load(f)

#             if isinstance(data, dict):
#                 if data.get("STATIC_SYSTEM_PROMPT"):
#                     static_part = data["STATIC_SYSTEM_PROMPT"].strip()

#                 if data.get("DEFAULT_DYNAMIC_PART"):
#                     dynamic_part = data["DEFAULT_DYNAMIC_PART"].strip()

#         except Exception as e:
#             # Fail-safe: log and continue with defaults
#             print(f"⚠️ Warning: Failed to read system_prompts.json, using defaults. Error: {e}")

#     # Final safety check (should never fail now)
#     if not static_part or not dynamic_part:
#         raise RuntimeError(
#             "❌ Both STATIC_SYSTEM_PROMPT and DEFAULT_DYNAMIC_PART must be present"
#         )

#     return f"{static_part}\n\n{dynamic_part}"

def get_system_prompt() -> str:
    """
    Reads STATIC + DYNAMIC prompt parts from system_prompts.json.

    Fallback rules:
    - If file does NOT exist → use defaults from summary_utils.py
    - If file exists but keys are missing or empty → use defaults
    - If file provides valid values → override defaults
    """
    import os
    import json

    # Always start with defaults (source of truth)
    static_part = (STATIC_SYSTEM_PROMPT or "").strip()
    dynamic_part = (DEFAULT_DYNAMIC_PART or "").strip()

    current_dir = os.path.dirname(os.path.abspath(__file__))
    prompt_file_path = os.path.join(
        current_dir,
        "Output_prompt",
        "system_prompts.json"
    )

    # Try to override defaults ONLY if file exists
    if os.path.exists(prompt_file_path):
        try:
            with open(prompt_file_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            if isinstance(data, dict):
                file_static = (data.get("STATIC_SYSTEM_PROMPT") or "").strip()
                file_dynamic = (data.get("DEFAULT_DYNAMIC_PART") or "").strip()

                # Override only if value is non-empty
                if file_static:
                    static_part = file_static

                if file_dynamic:
                    dynamic_part = file_dynamic

        except Exception as e:
            # Fail-safe: defaults remain intact
            print(
                f"⚠️ Warning: Failed to read system_prompts.json. "
                f"Using defaults from summary_utils.py. Error: {e}"
            )

    # Final hard safety check
    if not static_part or not dynamic_part:
        raise RuntimeError(
            "❌ Default prompts in summary_utils.py are missing or empty"
        )
    return f"{static_part}\n\n{dynamic_part}"


# ✅ Main prompt message builder
def build_summary_prompt(input_data: dict) -> list:
    try:
        # Validate input using Pydantic
        validated_data = SummaryInput(**input_data)
    except ValidationError as e:
        raise ValueError(f"❌ Invalid input format for summary prompt:\n{e}")

    formatted_input = json.dumps(validated_data.dict(), indent=2)
    
    # Dynamically fetch the system prompt
    full_system_prompt = get_system_prompt()
   
    return [
        {"role": "system", "content": full_system_prompt},
        {"role": "user", "content": formatted_input}
    ]

# ✅ Optional Output Format Verifier (simple check)
def is_valid_summary_format(output: str) -> bool:
    required_sections = ["summary", "chart_details", "suggested_followups"]
    return all(section in output for section in required_sections)


# ✅ Response Cleaner (strips Markdown fences)
def clean_json_response(response_text: str) -> str:
    """
    Removes ```json ... ``` or ``` ... ``` fences from the string
    so it can be parsed by json.loads().
    """
    # Remove ```json from start
    pattern = r"^```[a-zA-Z]*\n"
    response_text = re.sub(pattern, "", response_text.strip())
    # Remove ``` from end
    if response_text.endswith("```"):
        response_text = response_text[:-3]
    return response_text.strip()


if __name__ == "__main__":
    # Self-test when running this file directly
    print("running summary_utils.py test...")
    
    sample_input = {
        "original_query": "Total sales?",
        "total_refined_query": 1,
        "refined_query_list": ["Get total sales amount"],
        "query_sql_answer": [
            {
                "refined_query": "Get total sales amount",
                "generated_sql": "SELECT SUM(amount) FROM sales",
                "executed_sql_output": [{"total": 500000}],
                "remarks": "Executed successfully"
            }
        ]
    }
    
    try:
        messages = build_summary_prompt(sample_input)
        print("Prompt built successfully.") 
        # print("System Prompt Preview:", messages[0]["content"][:100], "...")
        print("User Prompt Preview:", messages[1]["content"][:100], "...")
        
        # Test Cleaner
        dirty_json = "```json\n{\"summary\": \"test\"}\n```"
        clean = clean_json_response(dirty_json)
        print(f"Cleaner test: '{dirty_json}' -> '{clean}'") 
        
    except Exception as e:
        print(f"Error: {e}") 
