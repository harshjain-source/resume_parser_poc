import os
import faiss
import numpy as np
from context import database_detail_ctx, retrieved_db_schema_for_query_ctx
from logger_utils import log_retrieved_schemas, log_retrieved_business


from db_schema_embeddings_load_in_ram import embeddings_in_ram  # Import the embeddings_in_ram variable


# Function to retrieve top-k similar results based on input query and threshold similarity
def retrieve_embeddings(input_text, db_type, db_name, top_k, threshold_similarity):
    try:
        # Sanitize and format the db_name and db_type
        db_name = db_name.lower().replace(" ", "_").replace("-", "_")  # Sanitize db_name
        db_type = db_type.lower()  # Convert to lowercase
        
        # Check if the db_type and db_name exist in embeddings_in_ram
        if db_type not in embeddings_in_ram["db"]:
            print(f"Error: Database type '{db_type}' not found in embeddings_in_ram.")
            return []
        
        if db_name not in embeddings_in_ram["db"][db_type]:
            print(f"Error: Database '{db_name}' not found in embeddings_in_ram under '{db_type}'.")
            return []

        # Retrieve the FAISS index and schema lines from embeddings_in_ram
        index = embeddings_in_ram["db"][db_type][db_name][0]["index_file"]  # FAISS index
        db_schema_lines = embeddings_in_ram["db"][db_type][db_name][0]["db_schema_lines"]  # Schema lines

        # Embed the input query to get the query vector
        query_embedding = embeddings_in_ram["models"][0].encode(input_text, convert_to_numpy=True).astype(np.float32)

        # print("before retrieveing top_k: ")
        # Perform the search on the FAISS index
        D, I = index.search(np.array([query_embedding]), top_k)

        # print("after retrieveing top_k: ")

        # Store the input and retrieved entries with similarity scores in a data structure (list of dictionaries)
        document_retrieved = {
            "input_text": input_text,
            "retrieved_entries": []
        }
        # print("retrieved entries: ")
        
        retrieved_logs = []
        for i, idx in enumerate(I[0]):
            # Get the distance (similarity score) and check if it is above the threshold
            similarity_score = D[0][i]

            if similarity_score <=threshold_similarity:

                log_entry = {
                    "idx": idx,
                    "schema": db_schema_lines[idx].strip(),
                    "score": similarity_score
                    }
                
                retrieved_logs.append(log_entry)

        
                #print("******************* schema IDX ",idx, " - ", db_schema_lines[idx].strip()," - score", similarity_score)
                # Add the retrieved entry to the structure
                document_retrieved["retrieved_entries"].append({
                    "db_schema": db_schema_lines[idx].strip(),  # Use db_schema_lines from embeddings_in_ram
                    "similarity_score": similarity_score
                })      


        log_retrieved_schemas(retrieved_logs)

        # Call the function to sort and extract only the sorted db_schema
        sorted_db_schema = extract_sorted_db_schema(document_retrieved)
        

        # print("retrieved entries3: ")

        # Return the sorted db_schema
        return sorted_db_schema

    except Exception as e:
        print(f"Error from retrieving embeddings: {str(e)}")
        return []
    

# Function to format the sorted db_schema
def format_db_schema(sorted_db_schema):
    formatted_output = ""
    db_schema_lines = sorted_db_schema.split("\n")
    
    current_table = ""
    table_details = ""

    for line in db_schema_lines:
        schema = line.split(";;")  # 👈 now using ;; as delimiter

        if len(schema) < 2:
            continue

        # --------------------------
        # Table Info (always schema[0])
        # --------------------------
        table_part = schema[0].strip()

        # Extract Table_Name and Table_Description
        if table_part.startswith("Table_Name:"):
            table_name = table_part.split(",")[0].replace("Table_Name:", "").strip()
            table_description = table_part.split("Table_Description:")[-1].strip() if "Table_Description:" in table_part else "Description not provided"
        else:
            continue

        # New table encountered
        if table_name != current_table:
            if current_table:
                formatted_output += table_details + "\n"
            current_table = table_name
            table_details = f"Table_Name: {table_name}, Table_Description: {table_description} ;;"

        # --------------------------
        # Column Info (after ;;)
        # --------------------------
        if len(schema) > 1:
            col_part = schema[1].strip()

            col_name = col_part.split("Column_Name:")[-1].split("(")[0].strip() if "Column_Name:" in col_part else "Unknown"
            data_type = col_part.split("Data_type:")[-1].split(",")[0].strip() if "Data_type:" in col_part else "Unknown"
            constraint = col_part.split("Constraint:")[-1].split(")")[0].strip() if "Constraint:" in col_part else "None"

            col_desc = col_part.split("Column_Description:")[-1].split(", Column_Sample_Values:")[0].strip() if "Column_Description:" in col_part else "None"
            sample_vals = col_part.split("Column_Sample_Values:")[-1].strip() if "Column_Sample_Values:" in col_part else "None"

            table_details += f"\n   - Column_Name: {col_name} (Data_type: {data_type} , Constraint: {constraint}), Column_Description: {col_desc},  Column_Sample_Values: {sample_vals}"

    formatted_output += table_details
    return formatted_output





# Function to extract the part before `Column_Description` (if it exists)
def extract_sortable_part(db_schema):
    # Check if 'Column_Description' is in the db_schema string
    if "Column_Description" in db_schema:
        # If 'Column_Description' exists, split at 'Column_Description' and return the part before it
        return db_schema.split("Column_Description")[0]
    else:
        # If 'Column_Description' does not exist, return the full string (use entire db_schema)
        return db_schema





# Function to sort and return only the sorted db_schema (line by line)
def extract_sorted_db_schema(document_retrieved):
    # Extract the retrieved entries
    retrieved_entries = document_retrieved.get("retrieved_entries", [])

    

    # Sorting logic: sort by the extracted part (either before 'Column_Description' or full string)
    retrieved_entries.sort(key=lambda x: extract_sortable_part(x['db_schema']))

    
    # Extract the sorted db_schema and return it as a multi-line string
    sorted_db_schema = "\n".join([entry['db_schema'] for entry in retrieved_entries])


    return sorted_db_schema


# Function to extract the part before `Column_Description` (if it exists)
def business_sortable_part(db_schema):
    # Check if 'Column_Description' is in the db_schema string
    if "Column_Description" in db_schema:
        # If 'Column_Description' exists, split at 'Column_Description' and return the part before it
        return db_schema.split("Column_Description")[0]
    else:
        # If 'Column_Description' does not exist, return the full string (use entire db_schema)
        return db_schema





# Function to sort and return only the sorted db_schema (line by line)
def business_sorted_db_schema(document_retrieved):
    # Extract the retrieved entries
    retrieved_entries = document_retrieved.get("retrieved_entries", [])

    

    # Sorting logic: sort by the extracted part (either before 'Column_Description' or full string)
    retrieved_entries.sort(key=lambda x: business_sortable_part(x['business_schema']))

    
    # Extract the sorted db_schema and return it as a multi-line string
    sorted_db_schema = "\n".join([entry['business_schema'] for entry in retrieved_entries])


    return sorted_db_schema

    
def get_business_db_schema_for_query(input_text, top_k=5, threshold_similarity=1.6):
    try:
        db_name = database_detail_ctx.get().get("label_name")
        print("DB NAME: ",db_name)
        db_type = database_detail_ctx.get().get("database_type")

        if db_type not in embeddings_in_ram["db"]:
            print(f"Error: Database type '{db_type}' not found in embeddings_in_ram.")
            return []
        
        if db_name not in embeddings_in_ram["db"][db_type]:
            print(f"Error: Database '{db_name}' not found in embeddings_in_ram under '{db_type}'.")
            return []

        business_index = embeddings_in_ram["db"][db_type][db_name][0].get("business_index_file", None)  # FAISS index (business)
        business_schema_lines = embeddings_in_ram["db"][db_type][db_name][0].get("business_schema_lines", [])  # Business schema lines

        if business_index is None:
            print("Error: Business index file is not available for this database.")
            return []

        # Embed the input query to get the query vector
        query_embedding = embeddings_in_ram["models"][0].encode(input_text, convert_to_numpy=True).astype(np.float32)

        # Perform the search on the FAISS index for business data
        D_business, I_business = business_index.search(np.array([query_embedding]), top_k)

        document_retrieved = {
            "input_text": input_text,
            "retrieved_entries": []
        }

        #print("#################",document_retrieved)
        retrieved_log = []
        for i, idx in enumerate(I_business[0]):
            similarity_score = D_business[0][i]
            
            #print("******************* IDX ",idx, " - ", business_schema_lines[idx].strip()," - score", similarity_score)
            if idx == -1:
                continue
            
            if similarity_score <= threshold_similarity:
                log_entry = {
                    "idx": idx,
                    "schema": business_schema_lines[idx].strip(),
                    "score": similarity_score
                    }
                
                retrieved_log.append(log_entry)
                #print("******************* IDX ",idx, " - ", business_schema_lines[idx].strip()," - score", similarity_score)
                document_retrieved["retrieved_entries"].append({
                    "business_schema": business_schema_lines[idx].strip(),
                    "similarity_score": similarity_score
                })
        log_retrieved_business(retrieved_log)
        # Sort and return the final business schema
        #print("#################",document_retrieved)
        sorted_business = business_sorted_db_schema(document_retrieved)
        #print("################# shoet ",sorted_business)
        
        return sorted_business

    except Exception as e:
        print(f"Error from retrieving business embeddings: {str(e)}")
        return []








def get_relevant_db_schema_for_query(input_text, top_k=20, threshold_similarity=0.00):
    """
    Reads the extracted schema and directly sets it into the ContextVar.
    """
    try:

        #================================ With retrieving the embeddings ============================

        # use  both  curr_user_query_ctx, database_detail_ctx to get actual retrieved schema 


        using_rag = True  # True or False

        if using_rag:
            # print("\n========== using rag ====================\n")
            db_name = database_detail_ctx.get().get("label_name")
            db_type = database_detail_ctx.get().get("database_type")
            sorted_db_schema = retrieve_embeddings(input_text, db_type, db_name, top_k, threshold_similarity)
            #print("sorted_db_schema",sorted_db_schema)   
            retrieved_db_schema_for_query_ctx.set(sorted_db_schema)
            formatted_db_schema = format_db_schema(sorted_db_schema)
            #print("formatted_db_schema",formatted_db_schema)
#             relationships = """

# --- Table-Relationships ---
#     1. CustTable.CustomerAccount → ProjTable.CustomerAccount (FOREIGN KEY)  
#     2. CustTable.CustomerAccount → CustTransOpen.AccountNum (FOREIGN KEY)  
#     3. CustTable.CustomerAccount → CustTrans.AccountNum (FOREIGN KEY)
#     4. ProjTable.CustomerAccount -> CustTable.CustomerAccount (FOREIGN KEY) 
#     5. CustTable.AddressState → States.StateCode (FOREIGN KEY)  
#     6. ProjTable.DimensionDisplayValue → BusinessLine.Business Line (FOREIGN KEY)
#     7. ProjTable.PRO_PCCode -> ZEmployeeMaster.EmployeeCode (FOREIGN KEY)
#     """

#             if db_name=="rodic_finance" and db_type=="mssql":
#             # Combine formatted schema and relationships
            final_schema_with_relations = formatted_db_schema
#                 #print("final_schema",final_schema_with_relations)
                
                
#             else:
#                 final_schema_with_relations = formatted_db_schema  
            print("final_schema for con ==",final_schema_with_relations)  
            
#             # print("input txt   :  ",input_text)
            
            retrieved_db_schema_for_query_ctx.set(final_schema_with_relations)

        else:    
            # print("\n========== without rag ====================\n")
            file_path = os.path.join("db_schema_embeddings", "extracted_schema.txt")
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"Schema file not found at: {file_path}")
            with open(file_path, "r", encoding="utf-8") as file:
                retrieved_db_schema_for_query_ctx.set(file.read().strip())

    except Exception as e:
        raise RuntimeError(f"Failed to load DB schema: {str(e)}")


if __name__ == "__main__":
    get_relevant_db_schema_for_query("what is total price", "test_db")
    from context import retrieved_db_schema_for_query_ctx
    # print(retrieved_db_schema_for_query_ctx.get())